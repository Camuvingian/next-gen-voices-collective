import { createRoot } from "react-dom/client";
import App from "./App";

declare global {
  interface Window {
    __NG_STYLE__?: string;
  }
}

let style = window.__NG_STYLE__ === "jazz" ? "jazz" : "control";
try {
  const st = localStorage.getItem("ng-style");
  if (st === "jazz" || st === "control") style = st;
} catch {
  /* storage blocked */
}
if (style === "jazz") document.documentElement.dataset.ngStyle = "jazz";

try {
  const t = localStorage.getItem("ng-theme");
  if (t && t !== "control" && ["graphite", "daylight"].includes(t)) document.documentElement.dataset.ngTheme = t;
  const hl = localStorage.getItem("ng-hl");
  const jazzKeys = ["jz-ruby", "jz-white", "jz-blue", "jz-pink", "jz-purple"];
  const controlKeys = ["hivis-yellow", "hivis-orange", "cone-orange", "rescue-orange", "beacon-amber", "lime-cream", "uv-purple", "alarm-red", "oxblood", "metal-red"];
  if (hl && (style === "jazz" ? jazzKeys : controlKeys).includes(hl)) document.documentElement.dataset.ngHl = hl;
  const title = localStorage.getItem("ng-title");
  if ((title === "gradient" || title === "metal") && style !== "jazz") document.documentElement.dataset.ngTitle = title;
} catch {
  /* storage blocked: default theme */
}

createRoot(document.getElementById("root")!).render(<App />);
