import { useEffect, useState } from "react";

/**
 * Site "style" (art direction), set as data-ng-style on <html>:
 *  - control (default, no attribute): moody-blue studio control room
 *  - jazz: New Orleans jazz club, art-deco type, neon script, piano rail
 */
export type NgStyle = "control" | "jazz";

export function readStyle(): NgStyle {
  return document.documentElement.dataset.ngStyle === "jazz" ? "jazz" : "control";
}

export function useNgStyle(): NgStyle {
  const [style, setStyle] = useState<NgStyle>(readStyle);
  useEffect(() => {
    const mo = new MutationObserver(() => setStyle(readStyle()));
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ["data-ng-style"] });
    return () => mo.disconnect();
  }, []);
  return style;
}
