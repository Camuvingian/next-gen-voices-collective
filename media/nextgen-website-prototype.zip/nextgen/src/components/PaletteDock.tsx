import { useEffect, useState } from "react";
import { readStyle, type NgStyle } from "../lib/style";

/**
 * PaletteDock: a design-review tool for choosing the highlight colour and
 * headline treatment. Applies them live by setting data-ng-hl and
 * data-ng-title on <html>. Remove before launch, or keep it behind ?review.
 */

export type TitleStyle = "flat" | "gradient" | "metal";

export type Highlight = {
  key: string;
  name: string;
  hex: string;
  ref: string;
  use: string;
  /** headline treatment this version is designed with */
  title: TitleStyle;
  /** optional richer swatch (gradients for metallic / gradient versions) */
  swatch?: string;
};

const METAL_RED = "linear-gradient(180deg, #ff9a9f 0%, #e3283c 38%, #7a0b17 52%, #ff5361 66%, #a01325 100%)";

export const HIGHLIGHTS: Highlight[] = [
  { key: "signal-green", name: "Signal green", hex: "#14E38A", ref: "Lit traffic-light green (approx.)", use: "The ‘go’ light: blue-green when lit", title: "flat" },
  { key: "hivis-yellow", name: "Hi-vis yellow", hex: "#F5FF00", ref: "EN ISO 20471 fluorescent yellow ≈ RAL 1026", use: "High-visibility vests and jackets", title: "flat" },
  { key: "hivis-orange", name: "Hi-vis orange", hex: "#FF3D1A", ref: "EN ISO 20471 fluorescent orange-red ≈ RAL 2005", use: "Rail and road-worker hi-vis", title: "flat" },
  { key: "cone-orange", name: "Traffic-cone orange", hex: "#FF7900", ref: "Safety orange (ANSI)", use: "Traffic cones, barriers", title: "flat" },
  { key: "rescue-orange", name: "Rescue orange", hex: "#FF4F00", ref: "International orange", use: "Life rafts, lifejackets, SOLAS rescue gear", title: "flat" },
  { key: "beacon-amber", name: "Beacon amber", hex: "#FFA421", ref: "≈ RAL 2007 Luminous bright orange", use: "Rotating amber warning beacons", title: "flat" },
  {
    key: "lime-cream",
    name: "Lime cream",
    hex: "#DAF78C",
    ref: "Soft luminous lime → mint (custom)",
    use: "Creamy glow-stick lime, gradient headlines",
    title: "gradient",
    swatch: "linear-gradient(135deg, #daf78c, #8ef0d0)",
  },
  {
    key: "uv-purple",
    name: "UV purple",
    hex: "#A774FF",
    ref: "Blacklight violet → pink (custom)",
    use: "Stage UV, gradient headlines",
    title: "gradient",
    swatch: "linear-gradient(135deg, #7aa2ff, #a774ff 50%, #ff7ad9)",
  },
  { key: "alarm-red", name: "Alarm red", hex: "#FF2B3A", ref: "≈ RAL 3024 Luminous red", use: "Fire alarms, emergency stops", title: "flat" },
  { key: "oxblood", name: "Dark red", hex: "#A3142B", ref: "Oxblood / ≈ RAL 3003 Ruby red (custom)", use: "Deep velvet-curtain red, nods to the old brand", title: "flat" },
  {
    key: "metal-red",
    name: "Metallic",
    hex: "#D11F33",
    ref: "Chrome titles, metallic red emphasis",
    use: "Brushed chrome with candy-apple red",
    title: "metal",
    swatch: METAL_RED,
  },
];

/** Jazz-club neon colours (used when the Jazz style is on). */
export const JAZZ_HIGHLIGHTS: Highlight[] = [
  { key: "jz-red", name: "Neon red", hex: "#FF2E3F", ref: "Classic red neon tube", use: "The supper-club sign over the door", title: "flat", swatch: "linear-gradient(160deg, #ff8a93, #ff2e3f 45%, #a3121f)" },
  { key: "jz-ruby", name: "Ruby", hex: "#D1112B", ref: "Deep red, matches the logo", use: "Velvet rope, lipstick, the logo", title: "flat", swatch: "linear-gradient(160deg, #ff5a66, #d1112b 45%, #6d0712)" },
  { key: "jz-white", name: "White neon", hex: "#F4F1EA", ref: "Pure black-and-white noir", use: "Marquee lights, no colour at all", title: "flat", swatch: "linear-gradient(160deg, #ffffff, #e9e6df 45%, #9c9993)" },
  { key: "jz-blue", name: "Blue note", hex: "#4FC3FF", ref: "Cold blue neon", use: "Late-set lighting", title: "flat", swatch: "linear-gradient(160deg, #c2ecff, #4fc3ff 45%, #145f8a)" },
  { key: "jz-pink", name: "Neon pink", hex: "#FF5FA2", ref: "Hot pink neon", use: "Cocktail-bar signs", title: "flat", swatch: "linear-gradient(160deg, #ffc2dc, #ff5fa2 45%, #a3174f)" },
  { key: "jz-purple", name: "Violet", hex: "#B26BFF", ref: "Argon-mercury violet", use: "Backstage glow", title: "flat", swatch: "linear-gradient(160deg, #e3ccff, #b26bff 45%, #5a2bc4)" },
];

const STYLE_DEFAULT: Record<NgStyle, string> = { control: "signal-green", jazz: "jz-red" };

const TITLE_OPTIONS: { key: TitleStyle; label: string }[] = [
  { key: "flat", label: "Flat" },
  { key: "gradient", label: "Gradient" },
  { key: "metal", label: "Metallic" },
];

/** Painted-sign references: shown for comparison, too dark to work as highlights on navy. */
const REFERENCES = [
  { name: "RAL 6024 Traffic green", hex: "#008754" },
  { name: "RAL 2009 Traffic orange", hex: "#E15501" },
  { name: "RAL 3020 Traffic red", hex: "#C1121C" },
  { name: "RAL 5017 Traffic blue", hex: "#0E518D" },
];


function store(k: string, v: string) {
  try {
    localStorage.setItem(k, v);
  } catch {
    /* storage blocked */
  }
}

export function applyHighlight(key: string) {
  if (key === STYLE_DEFAULT[readStyle()]) delete document.documentElement.dataset.ngHl;
  else document.documentElement.dataset.ngHl = key;
  store("ng-hl", key);
}

export function applyTitle(t: TitleStyle) {
  if (t === "flat") delete document.documentElement.dataset.ngTitle;
  else document.documentElement.dataset.ngTitle = t;
  store("ng-title", t);
}

export function applyStyle(st: NgStyle) {
  if (st === "control") delete document.documentElement.dataset.ngStyle;
  else document.documentElement.dataset.ngStyle = st;
  store("ng-style", st);
}

export function PaletteDock() {
  const [open, setOpen] = useState(false);
  const [style, setStyle] = useState<NgStyle>(readStyle);
  const list = style === "jazz" ? JAZZ_HIGHLIGHTS : HIGHLIGHTS;
  const [hl, setHl] = useState<string>(() => document.documentElement.dataset.ngHl || STYLE_DEFAULT[readStyle()]);
  const [title, setTitle] = useState<TitleStyle>(() => (document.documentElement.dataset.ngTitle as TitleStyle) || "flat");
  const current = list.find((h) => h.key === hl) ?? list[0];

  const pickStyle = (st: NgStyle) => {
    setStyle(st);
    applyStyle(st);
    // each style starts from its own default colour and flat headlines
    delete document.documentElement.dataset.ngHl;
    store("ng-hl", STYLE_DEFAULT[st]);
    setHl(STYLE_DEFAULT[st]);
    setTitle("flat");
    applyTitle("flat");
    window.scrollTo({ top: 0 });
    window.dispatchEvent(new Event("ng:reload"));
  };

  useEffect(() => {
    if (!open) return;
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [open]);

  const pick = (h: Highlight) => {
    setHl(h.key);
    applyHighlight(h.key);
    // each version comes with the headline treatment it was designed with
    setTitle(h.title);
    applyTitle(h.title);
  };
  const pickTitle = (t: TitleStyle) => {
    setTitle(t);
    applyTitle(t);
  };

  const chip = (h: Highlight) => ({ background: h.swatch ?? h.hex });

  return (
    <div className={["ng-dock", open && "is-open"].filter(Boolean).join(" ")}>
      <div className="ng-dock-panel" id="ng-dock-panel" role="dialog" aria-label="Highlight colour" hidden={!open}>
        <div className="ng-dock-head">
          <p className="ng-eyebrow">Highlight colour</p>
          <button className="ng-dock-x" onClick={() => setOpen(false)} aria-label="Close palette">
            ×
          </button>
        </div>
        <div className="ng-dock-list" role="radiogroup" aria-label="Highlight colours">
          {list.map((h) => (
            <button key={h.key} role="radio" aria-checked={hl === h.key} className={["ng-dock-item", hl === h.key && "is-on"].filter(Boolean).join(" ")} onClick={() => pick(h)}>
              <span className="ng-dock-chip" style={chip(h)} aria-hidden="true">
                <i />
              </span>
              <span className="ng-dock-text">
                <strong>{h.name}</strong>
                <small>{h.use}</small>
                <small className="ng-dock-ref">{h.ref}</small>
              </span>
              <code>{h.hex}</code>
            </button>
          ))}
        </div>
        {style === "control" && (
          <>
            <p className="ng-dock-sub">Painted-sign references</p>
            <div className="ng-dock-refs">
              {REFERENCES.map((r) => (
                <span key={r.name} className="ng-dock-refitem">
                  <span style={{ background: r.hex }} aria-hidden="true" />
                  {r.name} <code>{r.hex}</code>
                </span>
              ))}
            </div>
            <p className="ng-dock-note">Screen values approximate fluorescent pigments, which glow brighter than any screen can show.</p>
          </>
        )}
      </div>
      <div className="ng-dock-bar">
        <div className="ng-dock-seg ng-dock-style" role="radiogroup" aria-label="Site style">
          {(["control", "jazz"] as const).map((st) => (
            <button key={st} role="radio" aria-checked={style === st} className={style === st ? "is-on" : ""} onClick={() => style !== st && pickStyle(st)}>
              {st === "control" ? "Control room" : "Noir club"}
            </button>
          ))}
        </div>
        <div className="ng-dock-strip" role="radiogroup" aria-label="Quick highlight">
          {list.map((h) => (
            <button
              key={h.key}
              role="radio"
              aria-checked={hl === h.key}
              aria-label={h.name}
              title={`${h.name} ${h.hex}`}
              className={["ng-dock-dot", hl === h.key && "is-on"].filter(Boolean).join(" ")}
              style={chip(h)}
              onClick={() => pick(h)}
            >
              <i />
            </button>
          ))}
        </div>
        <div className="ng-dock-row">
          <div className="ng-dock-seg" role="radiogroup" aria-label="Headline style" hidden={style === "jazz"}>
            {TITLE_OPTIONS.map((o) => (
              <button key={o.key} role="radio" aria-checked={title === o.key} className={title === o.key ? "is-on" : ""} onClick={() => pickTitle(o.key)}>
                {o.label}
              </button>
            ))}
          </div>
          <button
            type="button"
            className="ng-dock-reload"
            onClick={() => window.dispatchEvent(new Event("ng:reload"))}
            aria-label="Reload page and replay animations"
            title="Reload page"
          >
            <svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 11a8 8 0 1 0-2.3 5.7" />
              <path d="M20 4v7h-7" />
            </svg>
            <span>Reload</span>
          </button>
          <button className="ng-dock-btn" onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-controls="ng-dock-panel">
            <span className="ng-dock-name">{current.name}</span>
            <span aria-hidden="true">{open ? "▾" : "▴"}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
