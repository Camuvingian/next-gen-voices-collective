/**
 * Pillar glyphs — four small "studio gear screens", one per rehearsal pillar.
 *
 *   blend      oscilloscope   three noisy voice traces lock into one bright trace
 *   harmony    XY scope       Lissajous figure built from the 4:5:6 major-triad ratios
 *   precision  step sequencer 16-step grid, playhead, onsets land exactly on the grid
 *   presence   spectrum       LED spectrum analyser, energy builds, peak-hold markers
 *
 * Canvas 2D, DPR-aware, paused offscreen, theme-aware via CSS custom properties.
 * Styles live in src/theme/glyphs.css (classes prefixed `ng-glyph`).
 */
import { useEffect, useRef } from "react";

export type PillarKind = "blend" | "harmony" | "precision" | "presence";

/* ────────────────────────────────────────────────────────────────
   Theme
   ──────────────────────────────────────────────────────────────── */

type RGB = readonly [number, number, number];

interface Theme {
  bg: RGB;
  bgSunken: RGB;
  fg: RGB;
  muted: RGB;
  accent: RGB;
  accentInk: RGB;
  blue: RGB; // secondary trace colour (already darkened on light backgrounds)
  light: boolean;
  mono: string;
}

const FALLBACK = {
  bg: [13, 20, 36] as RGB,
  bgSunken: [7, 12, 24] as RGB,
  fg: [232, 238, 247] as RGB,
  muted: [138, 151, 173] as RGB,
  accent: [255, 212, 0] as RGB,
  accentInk: [255, 212, 0] as RGB,
  glow2: [120, 160, 215] as RGB,
  mono: '"IBM Plex Mono", ui-monospace, SFMono-Regular, Menlo, monospace',
};

function clamp01(v: number) {
  return v < 0 ? 0 : v > 1 ? 1 : v;
}

function parseColor(s: string): RGB | null {
  const v = s.trim();
  if (!v) return null;
  if (v[0] === "#") {
    const h = v.slice(1);
    if (h.length === 3 || h.length === 4) return [parseInt(h[0] + h[0], 16), parseInt(h[1] + h[1], 16), parseInt(h[2] + h[2], 16)];
    if (h.length === 6 || h.length === 8) return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
    return null;
  }
  const m = v.match(/rgba?\(([^)]+)\)/);
  const parts = (m ? m[1] : v).split(/[\s,/]+/).filter(Boolean).map(Number);
  if (parts.length >= 3 && parts.slice(0, 3).every((n) => Number.isFinite(n))) return [parts[0], parts[1], parts[2]];
  return null;
}

function luminance([r, g, b]: RGB) {
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
}

function mix(a: RGB, b: RGB, k: number): RGB {
  return [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
}

function rgba(c: RGB, a: number) {
  return `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${clamp01(a)})`;
}

function readTheme(): Theme {
  const cs = typeof window !== "undefined" ? getComputedStyle(document.documentElement) : null;
  const get = (name: string) => (cs ? cs.getPropertyValue(name) : "");
  const bg = parseColor(get("--ng-bg")) ?? FALLBACK.bg;
  const light = luminance(bg) > 0.5;
  const fg = parseColor(get("--ng-fg")) ?? FALLBACK.fg;
  const accent = parseColor(get("--ng-accent")) ?? parseColor(`rgb(${get("--ng-glow")})`) ?? FALLBACK.accent;
  const glow2 = parseColor(`rgb(${get("--ng-glow-2")})`) ?? FALLBACK.glow2;
  const monoRaw = get("--font-mono").trim();
  return {
    bg,
    bgSunken: parseColor(get("--ng-bg-sunken")) ?? FALLBACK.bgSunken,
    fg,
    muted: parseColor(get("--ng-muted")) ?? FALLBACK.muted,
    accent,
    accentInk: parseColor(get("--ng-accent-ink")) ?? (light ? mix(accent, [0, 0, 0], 0.55) : accent),
    // on a light screen the blue needs to be pulled towards the (dark) foreground to read
    blue: light ? mix(glow2, fg, 0.4) : glow2,
    light,
    mono: monoRaw || FALLBACK.mono,
  };
}

/* ────────────────────────────────────────────────────────────────
   Drawing helpers
   ──────────────────────────────────────────────────────────────── */

interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

interface Frame {
  ctx: CanvasRenderingContext2D;
  w: number;
  h: number;
  r: Rect; // content rect (keeps the bottom status bar clear)
  t: number; // seconds, pauses when offscreen
  dt: number;
  energy: number; // 0 at rest → 1 while the card is hovered / focused
  theme: Theme;
  still: boolean; // reduced-motion single frame
}

interface ScopeSpec<S> {
  label: string;
  fade: number; // phosphor persistence: 1 = no trails, lower = longer trails
  init(): S;
  graticule(f: Frame): void;
  draw(f: Frame, s: S): void;
  readout(f: Frame, s: S): string;
}

function polyline(pts: ArrayLike<number>, n: number): Path2D {
  const p = new Path2D();
  for (let i = 0; i < n; i++) {
    const x = pts[i * 2];
    const y = pts[i * 2 + 1];
    if (i === 0) p.moveTo(x, y);
    else p.lineTo(x, y);
  }
  return p;
}

/** A phosphor beam: wide soft halo + core. Yellow on a light screen gets a dark underlay. */
function beam(ctx: CanvasRenderingContext2D, path: Path2D, color: RGB, alpha: number, core: number, ink?: RGB) {
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.lineWidth = core * 4.5;
  ctx.strokeStyle = rgba(color, alpha * 0.07);
  ctx.stroke(path);
  ctx.lineWidth = core * 2.2;
  ctx.strokeStyle = rgba(color, alpha * 0.18);
  ctx.stroke(path);
  if (ink) {
    ctx.lineWidth = core + 1.6;
    ctx.strokeStyle = rgba(ink, alpha * 0.75);
    ctx.stroke(path);
  }
  ctx.lineWidth = core;
  ctx.strokeStyle = rgba(color, alpha);
  ctx.stroke(path);
}

function gridLines(ctx: CanvasRenderingContext2D, r: Rect, cols: number, rows: number, color: RGB, alpha: number, centre = true) {
  ctx.lineWidth = 1;
  ctx.strokeStyle = rgba(color, alpha);
  ctx.beginPath();
  for (let i = 0; i <= cols; i++) {
    const x = Math.round(r.x + (r.w * i) / cols) + 0.5;
    ctx.moveTo(x, r.y);
    ctx.lineTo(x, r.y + r.h);
  }
  for (let j = 0; j <= rows; j++) {
    const y = Math.round(r.y + (r.h * j) / rows) + 0.5;
    ctx.moveTo(r.x, y);
    ctx.lineTo(r.x + r.w, y);
  }
  ctx.stroke();
  if (centre) {
    ctx.strokeStyle = rgba(color, alpha * 2.2);
    ctx.beginPath();
    const cy = Math.round(r.y + r.h / 2) + 0.5;
    ctx.moveTo(r.x, cy);
    ctx.lineTo(r.x + r.w, cy);
    ctx.stroke();
  }
}

const TAU = Math.PI * 2;
const smooth = (a: number, b: number, v: number) => {
  const u = clamp01((v - a) / (b - a));
  return u * u * (3 - 2 * u);
};

/* ────────────────────────────────────────────────────────────────
   BLEND — oscilloscope, three voices lock into one trace
   ──────────────────────────────────────────────────────────────── */

interface BlendState {
  pts: Float32Array[]; // three voices
  sum: Float32Array;
  n: number;
}

const BLEND_N = 128;

const blend: ScopeSpec<BlendState> = {
  label: "CH 1–3 · BLEND",
  fade: 0.5,
  init: () => ({ pts: [0, 1, 2].map(() => new Float32Array(BLEND_N * 2)), sum: new Float32Array(BLEND_N * 2), n: BLEND_N }),
  graticule({ ctx, r, theme }) {
    gridLines(ctx, r, 10, 4, theme.fg, theme.light ? 0.09 : 0.07);
  },
  draw(f, s) {
    const { ctx, r, t, theme, energy } = f;
    const mid = r.y + r.h / 2;
    const amp = r.h * 0.4;
    const speed = 3.4 + energy * 1.6;
    const cycles = 2.6;
    const n = s.n;
    for (let i = 0; i < n; i++) {
      const u = i / (n - 1);
      const x = r.x + u * r.w;
      // how far along the "locking" process this column is — hover locks earlier
      const lock = smooth(0.12, 0.88 - energy * 0.22, u);
      const spread = 1 - lock;
      let sy = 0;
      for (let k = 0; k < 3; k++) {
        const v = k - 1; // -1, 0, 1
        const wobble = 0.32 * Math.sin(u * 9 + t * 2.1 + k * 2.1) + 0.18 * Math.sin(u * 23 - t * 3.3 + k * 0.9);
        const phase = spread * (v * (1.35 + 0.35 * Math.sin(t * 0.7 + k)) + wobble);
        const a = 0.72 + spread * (v * 0.26 + 0.12 * Math.sin(t * 1.9 + k * 1.7));
        const jitter = spread * (Math.sin(u * 211 + t * 57 + k * 13) * 1.2); // live-signal hash
        const y = mid - amp * a * Math.sin(TAU * cycles * u - t * speed + phase) + jitter;
        s.pts[k][i * 2] = x;
        s.pts[k][i * 2 + 1] = y;
        sy += y;
      }
      s.sum[i * 2] = x;
      s.sum[i * 2 + 1] = sy / 3;
    }
    // three blue voices, dimming as they lock
    for (let k = 0; k < 3; k++) beam(ctx, polyline(s.pts[k], n), theme.blue, 0.75, 1.1);
    // the locked trace, fading in along the right-hand portion
    const lockedFrom = Math.floor(n * 0.42);
    const seg = s.sum.subarray(lockedFrom * 2);
    const p = polyline(seg, n - lockedFrom);
    // fade-in: draw twice, a faint full-length and a bright right-hand half
    beam(ctx, p, theme.accent, 0.55 + energy * 0.2, 1.3, theme.light ? theme.accentInk : undefined);
    const brightFrom = Math.floor(n * 0.68);
    beam(ctx, polyline(s.sum.subarray(brightFrom * 2), n - brightFrom), theme.accent, 1, 1.6, theme.light ? theme.accentInk : undefined);
    // write head
    const hx = s.sum[(n - 1) * 2];
    const hy = s.sum[(n - 1) * 2 + 1];
    const g = ctx.createRadialGradient(hx, hy, 0, hx, hy, 9);
    g.addColorStop(0, rgba(theme.accent, 0.9));
    g.addColorStop(1, rgba(theme.accent, 0));
    ctx.fillStyle = g;
    ctx.fillRect(hx - 9, hy - 9, 18, 18);
  },
  readout({ t, energy }) {
    const v = Math.min(100, Math.round(96.5 + 2.5 * Math.sin(t * 0.9) + energy * 4));
    return `LOCK ${v}%`;
  },
};

/* ────────────────────────────────────────────────────────────────
   HARMONY — XY scope, 4:5:6 Lissajous with a phosphor comet
   ──────────────────────────────────────────────────────────────── */

interface HarmonyState {
  full: Float32Array;
  n: number;
}

const HARM_N = 420;
const HARM_CHUNKS = 26;

function harmPoint(theta: number, t: number, rx: number, ry: number, cx: number, cy: number): [number, number] {
  const phi = t * 0.19;
  const psi = t * 0.11;
  return [cx + rx * Math.sin(4 * theta + phi), cy - ry * (0.56 * Math.sin(5 * theta) + 0.44 * Math.sin(6 * theta + psi))];
}

const harmony: ScopeSpec<HarmonyState> = {
  label: "XY · 4 : 5 : 6",
  fade: 1,
  init: () => ({ full: new Float32Array((HARM_N + 1) * 2), n: HARM_N + 1 }),
  graticule({ ctx, r, theme }) {
    const a = theme.light ? 0.09 : 0.07;
    gridLines(ctx, r, 8, 4, theme.fg, a, false);
    const cx = r.x + r.w / 2;
    const cy = r.y + r.h / 2;
    ctx.strokeStyle = rgba(theme.fg, a * 2.4);
    ctx.beginPath();
    ctx.moveTo(cx + 0.5, r.y);
    ctx.lineTo(cx + 0.5, r.y + r.h);
    ctx.moveTo(r.x, cy + 0.5);
    ctx.lineTo(r.x + r.w, cy + 0.5);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx, cy, Math.min(r.w, r.h) * 0.42, 0, TAU);
    ctx.stroke();
  },
  draw(f, s) {
    const { ctx, r, t, theme, energy } = f;
    const cx = r.x + r.w / 2;
    const cy = r.y + r.h / 2;
    const ry = r.h * 0.44;
    const rx = Math.min(r.w * 0.42, ry * 1.55);
    // full figure, faint blue afterglow
    for (let i = 0; i < s.n; i++) {
      const [x, y] = harmPoint((i / HARM_N) * TAU, t, rx, ry, cx, cy);
      s.full[i * 2] = x;
      s.full[i * 2 + 1] = y;
    }
    beam(ctx, polyline(s.full, s.n), theme.blue, 0.42 + energy * 0.15, 1);
    // the beam: a comet trailing behind the head
    const head = t * (1.15 + energy * 0.9);
    const len = 2.4 + energy * 1.2;
    const perChunk = 6;
    const ink = theme.light ? theme.accentInk : undefined;
    for (let c = 0; c < HARM_CHUNKS; c++) {
      const k0 = c / HARM_CHUNKS;
      const k1 = (c + 1) / HARM_CHUNKS;
      const pts: number[] = [];
      for (let j = 0; j <= perChunk; j++) {
        const k = k0 + ((k1 - k0) * j) / perChunk;
        const theta = head - len * (1 - k);
        const [x, y] = harmPoint(theta, t, rx, ry, cx, cy);
        pts.push(x, y);
      }
      const a = k1 * k1;
      beam(ctx, polyline(pts, perChunk + 1), theme.accent, a, 0.9 + a * 1.1, ink);
    }
    const [hx, hy] = harmPoint(head, t, rx, ry, cx, cy);
    const g = ctx.createRadialGradient(hx, hy, 0, hx, hy, 10);
    g.addColorStop(0, rgba(theme.light ? theme.accentInk : [255, 255, 255], 0.9));
    g.addColorStop(0.25, rgba(theme.accent, 0.8));
    g.addColorStop(1, rgba(theme.accent, 0));
    ctx.fillStyle = g;
    ctx.fillRect(hx - 10, hy - 10, 20, 20);
  },
  readout({ t }) {
    const deg = Math.round((((t * 0.19) % TAU) / TAU) * 360);
    return `φ ${String(deg).padStart(3, "0")}°`;
  },
};

/* ────────────────────────────────────────────────────────────────
   PRECISION — 16-step sequencer, S/A/T/B lanes, onsets on the grid
   ──────────────────────────────────────────────────────────────── */

const STEPS = 16;
const LANES = ["S", "A", "T", "B"] as const;
const PATTERN: readonly (readonly number[])[] = [
  [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0],
  [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0],
  [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0],
  [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0],
];
const STEP_SEC = 0.16;
const BAR_SEC = STEP_SEC * STEPS;

interface PrecisionState {
  _: 0;
}

function seqLayout(r: Rect) {
  const labelW = 16;
  const gx = r.x + labelW;
  const gw = r.w - labelW;
  const gy = r.y + 4;
  const gh = r.h - 16; // leave room for step numbers
  const cw = gw / STEPS;
  const lh = gh / LANES.length;
  return { gx, gy, gw, gh, cw, lh };
}

const precision: ScopeSpec<PrecisionState> = {
  label: "SEQ 1/16 · PRECISION",
  fade: 0.62,
  init: () => ({ _: 0 }),
  graticule({ ctx, r, theme }) {
    const { gx, gy, gw, gh, cw, lh } = seqLayout(r);
    const a = theme.light ? 0.1 : 0.08;
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i <= STEPS; i++) {
      const x = Math.round(gx + i * cw) + 0.5;
      ctx.moveTo(x, gy);
      ctx.lineTo(x, gy + gh);
    }
    for (let j = 0; j <= LANES.length; j++) {
      const y = Math.round(gy + j * lh) + 0.5;
      ctx.moveTo(gx, y);
      ctx.lineTo(gx + gw, y);
    }
    ctx.strokeStyle = rgba(theme.fg, a);
    ctx.stroke();
    // beat lines (every 4 steps) a touch stronger
    ctx.beginPath();
    for (let i = 0; i <= STEPS; i += 4) {
      const x = Math.round(gx + i * cw) + 0.5;
      ctx.moveTo(x, gy - 2);
      ctx.lineTo(x, gy + gh + 2);
    }
    ctx.strokeStyle = rgba(theme.fg, a * 2.6);
    ctx.stroke();
    // lane + step labels
    ctx.fillStyle = rgba(theme.muted, 0.9);
    ctx.font = `500 9px ${theme.mono}`;
    ctx.textBaseline = "middle";
    ctx.textAlign = "left";
    LANES.forEach((l, j) => ctx.fillText(l, r.x + 1, gy + (j + 0.5) * lh));
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    for (let i = 0; i < STEPS; i += 4) ctx.fillText(String(i + 1).padStart(2, "0"), gx + (i + 0.5) * cw, gy + gh + 4);
  },
  draw(f, s) {
    void s;
    const { ctx, r, t, theme, energy, still } = f;
    const { gx, gy, gh, cw, lh } = seqLayout(r);
    const pos = still ? 8.35 : (t / STEP_SEC) % STEPS; // fractional step
    const inset = 2.5;
    const ink = theme.light ? theme.accentInk : null;
    for (let j = 0; j < LANES.length; j++) {
      for (let i = 0; i < STEPS; i++) {
        if (!PATTERN[j][i]) continue;
        const x = gx + i * cw + inset;
        const y = gy + j * lh + inset;
        const w = cw - inset * 2;
        const h = lh - inset * 2;
        // time since the playhead crossed this step (within the bar)
        let age = (pos - i) * STEP_SEC;
        if (age < 0) age += BAR_SEC;
        const flash = Math.exp(-age / (0.22 + energy * 0.12));
        // armed state: dim blue block
        ctx.fillStyle = rgba(theme.blue, theme.light ? 0.55 : 0.42);
        ctx.fillRect(x, y, w, h);
        if (flash > 0.02) {
          ctx.fillStyle = rgba(theme.accent, flash);
          ctx.fillRect(x, y, w, h);
          if (ink) {
            ctx.strokeStyle = rgba(ink, flash * 0.8);
            ctx.lineWidth = 1;
            ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
          }
          // bloom around a fresh hit
          if (flash > 0.35) {
            const bx = x + w / 2;
            const by = y + h / 2;
            const rad = Math.max(w, h) * 1.2;
            const g = ctx.createRadialGradient(bx, by, 0, bx, by, rad);
            g.addColorStop(0, rgba(theme.accent, (flash - 0.35) * 0.5));
            g.addColorStop(1, rgba(theme.accent, 0));
            ctx.fillStyle = g;
            ctx.fillRect(bx - rad, by - rad, rad * 2, rad * 2);
          }
        }
      }
    }
    // playhead: a bright line that snaps on exact grid lines
    const px = gx + pos * cw;
    const near = Math.abs(pos - Math.round(pos)); // 0 on a grid line
    const snap = 1 - smooth(0, 0.18, near);
    const lineA = 0.55 + 0.45 * snap + energy * 0.1;
    ctx.fillStyle = rgba(theme.accent, lineA * 0.1);
    ctx.fillRect(px - 4, gy - 3, 8, gh + 6);
    ctx.fillStyle = rgba(ink ?? theme.accent, lineA);
    ctx.fillRect(px - 0.75, gy - 3, 1.5, gh + 6);
    // playhead cap
    ctx.fillStyle = rgba(theme.accent, 0.9);
    ctx.beginPath();
    ctx.moveTo(px - 3.5, gy - 4);
    ctx.lineTo(px + 3.5, gy - 4);
    ctx.lineTo(px, gy);
    ctx.closePath();
    ctx.fill();
  },
  readout() {
    return "±0 ms";
  },
};

/* ────────────────────────────────────────────────────────────────
   PRESENCE — LED spectrum analyser with peak-hold
   ──────────────────────────────────────────────────────────────── */

const BANDS = 24;
const PRES_GUTTER = 18; // room for the dB scale on the left

interface PresenceState {
  level: Float32Array;
  peak: Float32Array;
  hold: Float32Array;
  db: number;
}

function presenceLevel(i: number, t: number, energy: number) {
  const env = 0.92 * Math.exp(-(((i - 5.5) / 5) ** 2)) + 0.6 * Math.exp(-(((i - 14) / 6) ** 2)) + 0.3 * Math.exp(-(((i - 21) / 4) ** 2)) + 0.12;
  const u = (t * 0.16) % 1; // one "phrase" ≈ 6 s: build, hold, release
  const swell = smooth(0, 0.62, u) * (1 - smooth(0.8, 1, u));
  const flicker = 0.74 + 0.26 * (0.5 * Math.sin(t * 7.3 + i * 1.9) + 0.3 * Math.sin(t * 11.7 + i * 0.7) + 0.2 * Math.sin(t * 3.1 + i * 2.9));
  return clamp01(env * (0.32 + 0.68 * swell) * flicker * (1 + energy * 0.45));
}

const presence: ScopeSpec<PresenceState> = {
  label: "RTA 24 · PRESENCE",
  fade: 1,
  init: () => ({ level: new Float32Array(BANDS), peak: new Float32Array(BANDS), hold: new Float32Array(BANDS), db: -40 }),
  graticule({ ctx, r, theme }) {
    const a = theme.light ? 0.09 : 0.07;
    ctx.lineWidth = 1;
    ctx.strokeStyle = rgba(theme.fg, a);
    ctx.beginPath();
    for (let j = 0; j <= 4; j++) {
      const y = Math.round(r.y + (r.h - 12) * (j / 4)) + 0.5;
      ctx.moveTo(r.x + PRES_GUTTER - 3, y);
      ctx.lineTo(r.x + r.w, y);
    }
    ctx.stroke();
    ctx.fillStyle = rgba(theme.muted, 0.85);
    ctx.font = `500 8px ${theme.mono}`;
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    ["0", "-12", "-24", "-36"].forEach((l, j) => ctx.fillText(l, r.x + 1, r.y + (r.h - 12) * (j / 4) + 2));
  },
  draw(f, s) {
    const { ctx, r, t, theme, energy, dt, still } = f;
    const top = r.y;
    const bottom = r.y + r.h - 12;
    const gh = bottom - top;
    const gap = 2;
    const gx = r.x + PRES_GUTTER;
    const bw = (r.w - PRES_GUTTER - gap * (BANDS - 1)) / BANDS;
    const segH = 4;
    const segGap = 1.5;
    const nSeg = Math.floor((gh + segGap) / (segH + segGap));
    const hotFrom = Math.floor(nSeg * 0.72);
    const ink = theme.light ? theme.accentInk : null;
    let maxL = 0;
    for (let i = 0; i < BANDS; i++) {
      const target = presenceLevel(i, t, energy);
      // fast attack, slower release — like a real meter
      const cur = s.level[i];
      const lv = still ? target : target > cur ? cur + (target - cur) * Math.min(1, dt * 28) : cur + (target - cur) * Math.min(1, dt * 9);
      s.level[i] = lv;
      if (lv > maxL) maxL = lv;
      if (lv >= s.peak[i] || still) {
        s.peak[i] = lv;
        s.hold[i] = 0.7;
      } else {
        s.hold[i] -= dt;
        if (s.hold[i] < 0) s.peak[i] = Math.max(lv, s.peak[i] - dt * 0.38);
      }
      const x = gx + i * (bw + gap);
      const lit = Math.round(lv * nSeg);
      const pk = Math.min(nSeg - 1, Math.round(s.peak[i] * nSeg) - 1);
      for (let k = 0; k < nSeg; k++) {
        const y = bottom - (k + 1) * (segH + segGap) + segGap;
        const hot = k >= hotFrom;
        if (k < lit) {
          const col = hot ? theme.accent : theme.blue;
          const a = hot ? 1 : 0.55 + (k / nSeg) * 0.45;
          ctx.fillStyle = rgba(col, a);
          ctx.fillRect(x, y, bw, segH);
          if (hot && ink) {
            ctx.strokeStyle = rgba(ink, 0.6);
            ctx.lineWidth = 1;
            ctx.strokeRect(x + 0.5, y + 0.5, bw - 1, segH - 1);
          }
        } else if (k === pk && pk >= 0) {
          ctx.fillStyle = rgba(hot ? theme.accent : theme.fg, hot ? 1 : 0.8);
          ctx.fillRect(x, y, bw, segH);
          if (hot && ink) {
            ctx.strokeStyle = rgba(ink, 0.6);
            ctx.lineWidth = 1;
            ctx.strokeRect(x + 0.5, y + 0.5, bw - 1, segH - 1);
          }
        } else {
          ctx.fillStyle = rgba(theme.fg, theme.light ? 0.07 : 0.05);
          ctx.fillRect(x, y, bw, segH);
        }
      }
      // bloom off the hot zone
      if (lit > hotFrom) {
        const cy = bottom - lit * (segH + segGap);
        const g = ctx.createRadialGradient(x + bw / 2, cy, 0, x + bw / 2, cy, bw * 2.2);
        g.addColorStop(0, rgba(theme.accent, 0.35 * ((lit - hotFrom) / (nSeg - hotFrom))));
        g.addColorStop(1, rgba(theme.accent, 0));
        ctx.fillStyle = g;
        ctx.fillRect(x - bw * 2, cy - bw * 2.2, bw * 5, bw * 4.4);
      }
    }
    const db = Math.max(-40, 20 * Math.log10(Math.max(maxL, 0.0001)));
    s.db += (db - s.db) * (still ? 1 : Math.min(1, dt * 12));
  },
  readout(_, s) {
    const v = Math.min(0, s.db);
    const txt = v.toFixed(1);
    return `${v > -0.05 ? "" : "−"}${txt.replace("-", "")} dB`;
  },
};

/* ────────────────────────────────────────────────────────────────
   Component + canvas lifecycle
   ──────────────────────────────────────────────────────────────── */

const SCOPES: Record<PillarKind, ScopeSpec<unknown>> = {
  blend: blend as ScopeSpec<unknown>,
  harmony: harmony as ScopeSpec<unknown>,
  precision: precision as ScopeSpec<unknown>,
  presence: presence as ScopeSpec<unknown>,
};

const STILL_T = 3.9; // the frame rendered under prefers-reduced-motion (Presence near the top of its swell)
const BAR_H = 22; // bottom status bar height (px) — matches .ng-glyph-bar in glyphs.css

export interface PillarGlyphProps {
  kind: PillarKind;
  className?: string;
  /** Override the corner label (default is per-kind, e.g. "CH 1–3 · BLEND"). */
  label?: string;
}

export function PillarGlyph({ kind, className, label }: PillarGlyphProps) {
  const spec = SCOPES[kind];
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const readRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    const readEl = readRef.current;
    if (!wrap || !canvas) return;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return;

    const reduced = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
    const state = spec.init();
    let theme = readTheme();
    let w = 0;
    let h = 0;
    let dpr = 1;
    let backplate: HTMLCanvasElement | null = null;
    let needsClear = true;
    let t = 0;
    let last = 0;
    let dt = 0;
    let energy = 0;
    let energyTarget = 0;
    let raf = 0;
    let running = false;
    let visible = false;
    let lastReadout = "";

    const contentRect = (): Rect => ({ x: 10, y: 10, w: w - 20, h: h - 10 - BAR_H });

    const applyTheme = () => {
      theme = readTheme();
      wrap.dataset.light = theme.light ? "true" : "false";
      backplate = null;
      needsClear = true;
    };

    /** Background + graticule, drawn once per size/theme. The per-frame fade blends toward it. */
    const buildBackplate = () => {
      const bp = document.createElement("canvas");
      bp.width = Math.max(1, Math.round(w * dpr));
      bp.height = Math.max(1, Math.round(h * dpr));
      const c = bp.getContext("2d");
      if (!c) return bp;
      c.setTransform(dpr, 0, 0, dpr, 0, 0);
      c.fillStyle = rgba(theme.bgSunken, 1);
      c.fillRect(0, 0, w, h);
      spec.graticule({ ctx: c, w, h, r: contentRect(), t: 0, dt: 0, energy: 0, theme, still: true });
      return bp;
    };

    const frame = (still: boolean) => {
      if (w < 4 || h < 4) return;
      if (!backplate) backplate = buildBackplate();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.globalAlpha = needsClear || still ? 1 : spec.fade;
      ctx.drawImage(backplate, 0, 0, w, h);
      ctx.globalAlpha = 1;
      needsClear = false;
      const f: Frame = { ctx, w, h, r: contentRect(), t: still ? STILL_T : t, dt, energy, theme, still };
      spec.draw(f, state);
      const txt = spec.readout(f, state);
      if (readEl && txt !== lastReadout) {
        readEl.textContent = txt;
        lastReadout = txt;
      }
    };

    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      dt = last ? Math.min(0.05, (now - last) / 1000) : 1 / 60;
      last = now;
      t += dt;
      energy += (energyTarget - energy) * (1 - Math.exp(-dt * 5));
      frame(false);
    };
    const start = () => {
      if (running) return;
      running = true;
      last = 0;
      raf = requestAnimationFrame(tick);
    };
    const stop = () => {
      running = false;
      cancelAnimationFrame(raf);
    };
    const sync = () => {
      if (reduced) {
        stop();
        frame(true);
        return;
      }
      if (visible && !document.hidden) start();
      else stop();
    };

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      const nw = Math.round(rect.width);
      const nh = Math.round(rect.height);
      const ndpr = Math.min(2, window.devicePixelRatio || 1);
      if (nw === w && nh === h && ndpr === dpr) return;
      w = nw;
      h = nh;
      dpr = ndpr;
      canvas.width = Math.max(1, Math.round(w * dpr));
      canvas.height = Math.max(1, Math.round(h * dpr));
      backplate = null;
      needsClear = true;
      if (reduced) frame(true);
    };

    const ro = new ResizeObserver(resize);
    ro.observe(wrap);
    resize();

    const io = new IntersectionObserver(
      ([e]) => {
        visible = e.isIntersecting;
        sync();
      },
      { rootMargin: "80px 0px" },
    );
    io.observe(wrap);

    const onVis = () => sync();
    document.addEventListener("visibilitychange", onVis);

    const mo = new MutationObserver(() => {
      applyTheme();
      if (reduced) frame(true);
    });
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ["data-ng-theme", "data-ng-hl", "class", "style"] });
    applyTheme();

    // hover / focus on the whole card lifts the energy of the display
    const host = wrap.closest<HTMLElement>(".ng-pillar") ?? wrap;
    const up = () => {
      energyTarget = 1;
    };
    const down = () => {
      energyTarget = 0;
    };
    host.addEventListener("pointerenter", up);
    host.addEventListener("pointerleave", down);
    host.addEventListener("focusin", up);
    host.addEventListener("focusout", down);

    if (reduced) frame(true);

    return () => {
      stop();
      ro.disconnect();
      io.disconnect();
      mo.disconnect();
      document.removeEventListener("visibilitychange", onVis);
      host.removeEventListener("pointerenter", up);
      host.removeEventListener("pointerleave", down);
      host.removeEventListener("focusin", up);
      host.removeEventListener("focusout", down);
    };
  }, [spec]);

  return (
    <div ref={wrapRef} className={`ng-glyph-scope ng-glyph-scope--${kind}${className ? ` ${className}` : ""}`} aria-hidden="true">
      <canvas ref={canvasRef} className="ng-glyph-canvas" aria-hidden="true" />
      <div className="ng-glyph-bar">
        <span className="ng-glyph-label">
          <i className="ng-glyph-led" />
          {label ?? spec.label}
        </span>
        <span ref={readRef} className="ng-glyph-readout" />
      </div>
      <span className="ng-glyph-overlay" />
    </div>
  );
}
