import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNgStyle } from "../lib/style";
import { loadPiano, noteOff, noteOn, strike } from "../lib/piano";

/**
 * PianoRail: a real (sampled) piano running down the left edge, jazz/noir style only.
 * Hidden by default; the floating button bottom-left shows and hides it.
 *  - Scrolling moves a triad down the keyboard: the key at your scroll
 *    position plus the third and fifth above it go down.
 *  - Press a key to play it; hold to sustain; drag to glissando.
 *  - The ♪ button at the foot makes scrolling play the melody (off by default:
 *    browsers only allow sound after a tap).
 * Top of the rail is C3 (MIDI 48); notes rise as you go down the page.
 */

const WHITE_SEMIS = [0, 2, 4, 5, 7, 9, 11]; // C D E F G A B
const BLACK_AFTER: Record<number, number> = { 0: 1, 1: 3, 3: 6, 4: 8, 5: 10 }; // C# D# F# G# A#
const BASE_MIDI = 48; // C3
const NAMES = ["C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B"];

type Key = { id: string; kind: "white" | "black"; index: number; midi: number; top: number; h: number };

const readOpen = () => {
  try {
    return localStorage.getItem("ng-piano") === "on";
  } catch {
    return false;
  }
};

export function PianoRail() {
  const style = useNgStyle();
  const [open, setOpen] = useState(readOpen);
  const [vh, setVh] = useState(() => window.innerHeight);
  const [narrow, setNarrow] = useState(() => window.innerWidth < 700);
  const [lead, setLead] = useState(-1);
  const [held, setHeld] = useState<Set<string>>(() => new Set());
  const [sound, setSound] = useState(false);
  const [intro, setIntro] = useState(false);
  const lastLead = useRef(-1);
  const pointerDown = useRef(false);

  // the rail state lives on <html> so layout (body padding, nav offset) can follow it
  useEffect(() => {
    const on = style === "jazz" && open;
    if (on) document.documentElement.dataset.ngPiano = "on";
    else delete document.documentElement.dataset.ngPiano;
    try {
      localStorage.setItem("ng-piano", open ? "on" : "off");
    } catch {
      /* storage blocked */
    }
    if (on) {
      setIntro(true);
      const t = window.setTimeout(() => setIntro(false), 1400);
      return () => clearTimeout(t);
    }
  }, [open, style]);

  useEffect(() => {
    const r = () => {
      setVh(window.innerHeight);
      setNarrow(window.innerWidth < 700);
    };
    const up = () => (pointerDown.current = false);
    window.addEventListener("resize", r);
    window.addEventListener("pointerup", up);
    return () => {
      window.removeEventListener("resize", r);
      window.removeEventListener("pointerup", up);
    };
  }, []);

  const keyH = narrow ? 24 : 30;
  const keys = useMemo<Key[]>(() => {
    const n = Math.ceil(vh / keyH) + 1;
    const out: Key[] = [];
    for (let i = 0; i < n; i++) {
      const pos = i % 7;
      const oct = Math.floor(i / 7);
      out.push({ id: `w${i}`, kind: "white", index: i, midi: BASE_MIDI + oct * 12 + WHITE_SEMIS[pos], top: i * keyH, h: keyH });
      if (pos in BLACK_AFTER && i < n - 1) {
        const bh = keyH * 0.62;
        out.push({ id: `b${i}`, kind: "black", index: i, midi: BASE_MIDI + oct * 12 + BLACK_AFTER[pos], top: (i + 1) * keyH - bh / 2, h: bh });
      }
    }
    return out;
  }, [vh, keyH]);
  const whites = useMemo(() => keys.filter((k) => k.kind === "white"), [keys]);

  // scroll → moving triad (and, if enabled, the melody)
  useEffect(() => {
    if (style !== "jazz" || !open) return;
    let raf = 0;
    const update = () => {
      raf = 0;
      const max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      const p = Math.min(1, Math.max(0, window.scrollY / max));
      const i = Math.round(p * Math.max(1, whites.length - 5));
      setLead(i);
      if (i !== lastLead.current) {
        if (sound && lastLead.current !== -1) {
          const k = whites[i];
          if (k) strike(k.midi, 0.55);
        }
        lastLead.current = i;
      }
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, [style, open, whites, sound]);

  const press = useCallback((k: Key, velocity = 0.75) => {
    void noteOn(k.midi, velocity);
    setHeld((s) => new Set(s).add(k.id));
  }, []);
  const release = useCallback((k: Key) => {
    noteOff(k.midi);
    setHeld((s) => {
      const n = new Set(s);
      n.delete(k.id);
      return n;
    });
  }, []);

  if (style !== "jazz") return null;

  const isDown = (k: Key) => held.has(k.id) || (k.kind === "white" && (k.index === lead || k.index === lead + 2 || k.index === lead + 4));

  return (
    <>
      <aside className={["ng-piano", open && "is-open", intro && "is-intro"].filter(Boolean).join(" ")} aria-label="Piano" aria-hidden={!open}>
        <div className="ng-piano-keys" onPointerLeave={() => (pointerDown.current = false)}>
          {keys.map((k) => (
            <button
              key={k.id}
              type="button"
              tabIndex={-1}
              aria-label={`${NAMES[k.midi % 12]}${Math.floor(k.midi / 12) - 1}`}
              className={["ng-key", `is-${k.kind}`, isDown(k) && "is-down", k.kind === "white" && k.index === lead && "is-lead"].filter(Boolean).join(" ")}
              style={{ top: k.top, height: k.h, ["--i" as string]: k.index }}
              onPointerDown={(e) => {
                e.preventDefault();
                pointerDown.current = true;
                (e.currentTarget as HTMLElement).releasePointerCapture?.(e.pointerId);
                press(k);
              }}
              onPointerEnter={() => pointerDown.current && press(k, 0.6)}
              onPointerUp={() => release(k)}
              onPointerLeave={() => held.has(k.id) && release(k)}
            />
          ))}
        </div>
        <button
          type="button"
          className={["ng-piano-sound", sound && "is-on"].filter(Boolean).join(" ")}
          aria-pressed={sound}
          aria-label={sound ? "Stop playing notes while scrolling" : "Play notes while scrolling"}
          title={sound ? "Scroll sound on" : "Scroll sound off"}
          tabIndex={open ? 0 : -1}
          onClick={() => {
            const next = !sound;
            setSound(next);
            if (next) {
              void loadPiano();
              // C major arpeggio to confirm sound is on
              [60, 64, 67, 72].forEach((m, i) => window.setTimeout(() => strike(m, 0.5, 900), i * 110));
            }
          }}
        >
          ♪
        </button>
      </aside>
      <button
        type="button"
        className={["ng-piano-toggle", open && "is-open"].filter(Boolean).join(" ")}
        aria-pressed={open}
        aria-label={open ? "Hide piano" : "Show piano"}
        onClick={() => {
          setOpen((o) => !o);
          void loadPiano(); // decode samples ahead of the first key press
        }}
      >
        <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
          <rect x="3" y="4" width="18" height="16" rx="2" fill="none" stroke="currentColor" strokeWidth="1.5" />
          <path d="M8 4v16M13 4v16M18 4v16" stroke="currentColor" strokeWidth="1.2" />
          <rect x="6.6" y="4" width="2.8" height="9" fill="currentColor" />
          <rect x="11.6" y="4" width="2.8" height="9" fill="currentColor" />
          <rect x="16.6" y="4" width="2.8" height="9" fill="currentColor" />
        </svg>
        <span className="ng-piano-toggle-label">{open ? "Hide piano" : "Piano"}</span>
      </button>
    </>
  );
}
