# NextGen Voice Collective: website design prototype

A working React + TypeScript prototype of the standalone NextGen site: Home, About, Auditions (a multi-step application with video upload), Gallery and Contact (with booking fields), plus a new identity.

## The identity

**NextGen Interlock (approved logo, option 02).** The outlined NG draws into place, a travelling highlight finishes the stroke, the mark settles, then one metallic shimmer crosses it and it holds. Implemented with the supplied asset, unchanged: `src/components/NextGenLogo.tsx` + `NextGenLogo.css`. It plays in the hero and nav on load, in the footer when scrolled into view, and redraws (2.4 s cut) on the page-change curtain. Its five colour variables are mapped to site tokens in `tokens.css` (accent → highlight, secondary → highlight partner, edge → foreground, surface → background, shine → white), so it follows every theme, highlight and headline style without restarting.

**Palette: Control Room + emergency highlights.** Moody night-studio blues, with one emergency colour for highlights only: calls to action, emphasised words, live readouts and hazard-tape details. A palette button on the page swaps the highlight live:

| Highlight | Screen hex | Reference |
|---|---|---|
| Signal green (default) | #14E38A | Lit traffic-light green (approximation; the lit signal is blue-green) |
| Hi-vis yellow | #F5FF00 | EN ISO 20471 fluorescent yellow ≈ RAL 1026 Luminous yellow |
| Hi-vis orange | #FF3D1A | EN ISO 20471 fluorescent orange-red ≈ RAL 2005 Luminous orange |
| Traffic-cone orange | #FF7900 | Safety orange (ANSI) |
| Rescue orange | #FF4F00 | International orange, used on SOLAS life-saving gear |
| Beacon amber | #FFA421 | ≈ RAL 2007 Luminous bright orange |
| Lime cream | #DAF78C → #8EF0D0 | Creamy luminous lime into mint; gradient headlines (custom) |
| UV purple | #7AA2FF → #A774FF → #FF7AD9 | Blacklight violet into pink; gradient headlines (custom) |
| Alarm red | #FF2B3A | ≈ RAL 3024 Luminous red (fire alarms, emergency stops) |
| Dark red | #A3142B (text #D8304A) | Oxblood, close to the original brand red (custom) |
| Metallic | chrome + #D11F33 | Chrome headlines with candy-apple metallic red emphasis (custom) |

Painted-sign references (too dark to work as highlights on navy): RAL 6024 Traffic green #008754, RAL 2009 Traffic orange #E15501, RAL 3020 Traffic red #C1121C, RAL 5017 Traffic blue #0E518D. Fluorescent pigments glow brighter than any screen can show, so the screen values are approximations.

- `brand/`: static Interlock mark in Control (navy + signal green), Yellow (the asset's default palette) and Daylight colourways, plus the horizontal lockup.
- `src/components/Logo.tsx`: thin site wrappers (`<LogoMark draw />`, `<Logo />` lockup) around the asset. Below 32px use `animated={false}`, as the asset README advises.
- Type, studio-industrial: **Big Shoulders Display** (condensed headlines, all caps), **Big Shoulders Stencil** (emphasised words, like flight-case stencilling), **Barlow** (body copy; DIN-style signage feel) and **IBM Plex Mono** (labels, buttons and readouts, like console markings). All free on Google Fonts.
- Pillar graphics: four animated studio "screens": an oscilloscope (Blend), an XY scope drawing a 4:5:6 major-chord Lissajous figure (Harmony), a 16-step sequencer (Precision) and an LED spectrum analyser (Presence). They pause offscreen, respond to hover and follow the theme.

## Noir Club style (alternative art direction)

A second look, switchable from the palette dock (Control room / Noir club) and published as its own page that opens in noir. Nothing in the Control Room style changes.

- **Feel:** a 1920s–30s supper club in black and white, with film grain and a projector vignette. The only colour: the deep-red logo, the red sound waves, and one neon sign colour (Neon red by default; Ruby, White neon, Blue note, Neon pink, Violet in the dock).
- **Neon signs:** every emphasised word ("One sound.", "and", "every single week.") is a glass neon tube: white-hot core, tinted glass, a specular streak, layered glow and light spilling on the wall. Each sign starts unlit, ignites with a stutter once the page-load animation finishes, then holds steady; afterwards a visible sign flickers every 8–15 s at random (the hero sign most often). Timing: `NeonDirector.tsx`; look: `jazz.css`.
- **Type:** **Limelight** (art-deco caps), **Yellowtail** (the neon script), **Jost** body, **Josefin Sans** labels. The NEXTGEN wordmark in the nav shimmers every 8 s.
- **Logo:** the Interlock asset recoloured to a deep red gradient (edge, accent and shine variables only).
- **Buttons and colour dots:** subtle vertical gradients with a glassy top edge.
- **Piano:** hidden by default; the floating button bottom-left shows and hides it. Real sampled acoustic grand (rendered from the TimGM6mb General MIDI soundfont, GM program 0, with FluidSynth; 21 samples C3–C8, each note re-pitched exactly from the nearest one, ±1 semitone at most) with a small hall reverb. Press to play, hold to sustain, release lifts the damper, drag to glissando. Scrolling moves a triad down the keys; the ♪ button makes scrolling play the notes. Note mapping: top key C3, standard C-D-E-F-G-A-B layout with sharps between. Files: `PianoRail.tsx`, `lib/piano.ts`, `lib/pianoSamples.ts` (generated). TimGM6mb is GPL-2 licensed; for production, swap in a commercially licensed piano sample set (e.g. Salamander Grand, CC-BY) as small MP3 files.
- **Pillar cards:** sheet-music and stage animations (notes into unison, C–E–G into a chord, a metronome, a spotlight on the mic).
- Files: `src/theme/jazz.css`, `PianoRail.tsx`, `NeonDirector.tsx`, `JazzGlyph.tsx`, `lib/piano.ts`, `lib/style.ts`. Build output: `dist/jazz.html`.

## Recommended production stack

| Concern | Choice | Why |
|---|---|---|
| Framework | **Next.js 15 (App Router) + TypeScript** | SEO for "youth choir London" searches, image optimisation, server actions for the forms |
| Components | **shadcn/ui** (Radix primitives + Tailwind) | You own the code, it's fully themeable through CSS variables, accessible by default, and scales to any page count. The tokens in `src/theme/tokens.css` already use shadcn naming |
| Animation | **Motion** (Framer Motion) + **Lenis** | Page curtain, scroll reveals, shared-layout gallery transitions, smooth scroll |
| 3D | **@react-three/fiber + drei** | `HarmonicField` drops straight in as a `<shaderMaterial>` |
| Forms | **react-hook-form + zod** | The same zod schemas validate in the browser and on the server |
| Video uploads | **Mux Direct Upload** (or Cloudflare R2 presigned multipart) | Large phone videos go from the browser straight to storage, never through your server |
| Email | **Resend** + React Email | Confirmation to the parent, notification to you |
| CMS | **Sanity** | Lets you update gallery items, dates and copy without a developer |
| Instagram | **Behold.so** (or the Instagram Graph API) | A styled feed of the latest posts, refreshed hourly |
| Hosting | **Vercel** | Preview links for every change |

## Theming

Three themes ship in `tokens.css`. Try them with the switch in the footer:

- **Control** (default): night-studio navy, cool white, plus the highlight
- **Graphite**: neutral console grey, a harder-edged variant
- **Daylight**: pale studio blue-grey, with the highlight used as marker tape behind emphasised words

Headline style is a separate switch: Flat, Gradient (a soft white-to-tint sweep, emphasis runs highlight → partner hue) or Metallic (chrome, repeating per line). Each highlight opens with the style it was designed for, and any combination works. Themes and highlights combine freely (3 × 11). The palette button is a review tool; remove it before launch.

Every colour, font, radius and duration is a token. The 3D field reads its colours from tokens too, so it recolours live.

## Prototype notes

- The photo and video slots are art-directed placeholders. Each one states the shot it wants (for example "wide shot, full Collective on stage"), so swapping in the real assets is a one-to-one job.
- The forms validate fully but don't send anything yet. Upload progress is simulated.
- The 3D hero loads three.js r128 from cdnjs. If three.js or WebGL isn't available, the same maths draws in Canvas 2D instead.
- Build: `node build.mjs` (esbuild) produces `dist/index.html`. This prototype was built offline, so the components are hand-written in the shadcn pattern (cva variants) and swap for generated shadcn components one-to-one.

## To confirm before launch

- [ ] Contact email address (`hello@nextgenvoices.co.uk` is a placeholder) and domain
- [ ] Venue name ("Richmond & Putney Unitarian Church") and whether to show the fee on the site
- [ ] Copy for the audition process, privacy notice wording and video retention period (6 months is a placeholder)
- [ ] The fields on the current application form, mapped onto the four steps
- [ ] Real photos, the showreel cut and an Instagram access token
- [ ] Safeguarding: a policy page and named DSL contact (expected for an under-18s group)
