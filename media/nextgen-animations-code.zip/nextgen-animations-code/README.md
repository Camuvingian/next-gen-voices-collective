# NextGen animations: source code

Each numbered folder matches a prompt in ANIMATION_PROMPTS.md. Give the agent the prompt plus its folder.
`_shared/tokens.css` holds every colour, font and timing token the animations read (CSS custom properties).
Some CSS files contain more than one animation: search for the block named in the prompt (for example "Neon signs", "Wordmark", "Piano rail", "film grain").
These are working React 19 + TypeScript files from the prototype (built with esbuild, no framework). In Next.js add "use client" at the top of each component.
