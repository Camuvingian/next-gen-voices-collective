# Validation

Checked on 13 October 2026.

- Strict TypeScript checking and production build pass (`npm run build`).
- The generated HTML contains its React bundle, styles, font data and vector gallery illustrations; no external runtime URLs are required.
- Headless Chromium rendered the desktop hero and desktop/mobile pillar layouts without page errors.
- Automated interaction checks passed for live colour switching, animated metronome motion, pause/resume, the manual reduced-motion control, curtain scene commit and heading focus, gallery filtering, modal open/Escape/focus restoration, all demo form steps, piano opening, sound opt-in/key activation and closing.
- No horizontal page overflow at viewport widths 320, 390, 768, 1440 and 2560 pixels.
- Desktop and mobile static reduced-motion pillar views were visually inspected.

These checks are not a device-performance certification. Physical iOS Safari, Firefox, audio quality/latency, a real application's router, backend upload handling and assistive-technology testing remain integration checks. The demo form and upload slider deliberately do not submit or upload data.
