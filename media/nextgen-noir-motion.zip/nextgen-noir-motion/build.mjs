import { build, transform } from "esbuild";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { resolve, dirname } from "node:path";
const result = await build({
  entryPoints: ["src/demo/main.tsx"],
  bundle: true,
  write: false,
  minify: true,
  format: "iife",
  jsx: "automatic",
  target: ["es2022"],
  define: { "process.env.NODE_ENV": '"production"' },
});
const sheets = [
  "src/demo/fonts.css",
  "src/noir/tokens.css",
  "src/noir/logo.css",
  "src/noir/noir.css",
  "src/demo/demo.css",
];
let css = sheets
  .map((p) =>
    readFileSync(p, "utf8").replace(
      /url\((\.\.\/[^)]+)\)/g,
      (_, path) =>
        `url(data:font/ttf;base64,${readFileSync(resolve(dirname(p), path)).toString("base64")})`,
    ),
  )
  .join("\n");
css = (await transform(css, { loader: "css", minify: true })).code;
const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#090909"><title>NextGen — Noir Motion Collection</title><style>${css}</style></head><body><div id="root"></div><script>${result.outputFiles[0].text.replace(/<\/script/gi, "<\\/script")}</script></body></html>`;
mkdirSync("dist", { recursive: true });
writeFileSync("dist/nextgen-noir-preview.html", html);
console.log(
  `Built self-contained preview (${Math.round(Buffer.byteLength(html) / 1024)} KB)`,
);
