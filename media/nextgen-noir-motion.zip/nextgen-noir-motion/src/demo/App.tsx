import { useState, type CSSProperties } from "react";
import {
  NoirMotionProvider,
  HarmonicField,
  NeonText,
  Shimmer,
  RiseText,
  Reveal,
  PillarCard,
  NoirButton,
  FilmLayer,
  Marquee,
  StageCurtain,
  useStageTransition,
  NextGenLogo,
  NextGenPianoRail,
  NoirGallery,
  StepProgress,
  StepPanel,
  UploadProgress,
  SuccessMoment,
  type PillarKind,
} from "../noir";
const palettes = [
  ["Ruby", "#ff3c51", "255,60,81"],
  ["Pearl", "#f4f1ea", "244,241,234"],
  ["Ice", "#69cfff", "105,207,255"],
  ["Rose", "#ff79b6", "255,121,182"],
  ["Violet", "#be91ff", "190,145,255"],
];
const pillars: [PillarKind, string, string][] = [
  [
    "blend",
    "Individual voices. A single signature.",
    "Three independent voices lose their vibrato and meet in one luminous note.",
  ],
  [
    "harmony",
    "Find the space between.",
    "A C-major arpeggio opens into a chord, connected by fine voice-leading lines.",
  ],
  [
    "precision",
    "Nothing left to chance.",
    "The arm and four beat lamps share one clock. Every extreme lands on the beat.",
  ],
  [
    "presence",
    "Make the room listen.",
    "A silver microphone, drifting dust and a searching cone of stage light.",
  ],
];
function Art({ className = "" }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 500 500"
      fill="none"
      aria-hidden="true"
    >
      <circle cx="250" cy="250" r="203" />
      <circle cx="250" cy="250" r="196" />
      {Array.from({ length: 40 }, (_, i) => (
        <path key={i} d="M250 48V62" transform={`rotate(${i * 9} 250 250)`} />
      ))}
      <path d="M106 390V182Q106 38 250 38Q394 38 394 182V390M116 390V182Q116 48 250 48Q384 48 384 182V390M126 390V182Q126 58 250 58Q374 58 374 182V390" />
      {[-1, 1].map((s) => (
        <g key={s} transform={`translate(250 250) scale(${s} 1)`}>
          {[0, 1, 2, 3, 4].map((i) => (
            <path
              key={i}
              d={`M${75 + i * 14} 161V${-25 - i * 12}L${145 + i * 12} ${-90 - i * 12}`}
            />
          ))}
        </g>
      ))}
      <path d="M170 417H330M205 429H295M245 436l5 6 5-6" />
    </svg>
  );
}
function stageArt(i: number) {
  return (
    "data:image/svg+xml;charset=utf-8," +
    encodeURIComponent(
      `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600" viewBox="0 0 800 600"><defs><radialGradient id="b"><stop stop-color="#353332"/><stop offset="1" stop-color="#080809"/></radialGradient><linearGradient id="l" x2="0" y2="1"><stop stop-color="#eee9e0" stop-opacity=".03"/><stop offset="1" stop-color="#eee9e0" stop-opacity=".21"/></linearGradient></defs><rect width="800" height="600" fill="url(#b)"/>${[0, 1, 2, 3, 4].map((j) => `<path d="M${90 + j * 160} 0L${j * 135 - 90 + i * 20} 530H${j * 135 + 210 + i * 20}Z" fill="url(#l)"/>`).join("")}<ellipse cx="400" cy="530" rx="355" ry="35" fill="#aaa" opacity=".09"/>${Array.from(
        { length: i === 1 ? 1 : 9 },
        (_, j) => {
          let x = i === 1 ? 400 : 115 + j * 72;
          return `<ellipse cx="${x}" cy="${330 + Math.sin(j * 4) * 12}" rx="15" ry="19" fill="#080809"/><path d="M${x - 20} 354Q${x} 344 ${x + 20} 354L${x + 25} 465H${x - 25}ZM${x - 14} 460H${x + 14}V529H${x - 14}Z" fill="#080809"/>`;
        },
      ).join(
        "",
      )}<text x="40" y="560" fill="#aaa" font-family="sans-serif" font-size="12" letter-spacing="6">NEXTGEN / STAGE STUDY ${i + 1}</text></svg>`,
    )
  );
}
const images = [
  {
    id: "1",
    src: stageArt(0),
    alt: "Graphic study of an ensemble under stage beams",
    caption: "The collective",
    category: "Ensemble",
  },
  {
    id: "2",
    src: stageArt(1),
    alt: "Graphic study of a soloist in a spotlight",
    caption: "A moment in the light",
    category: "Solo",
  },
  {
    id: "3",
    src: stageArt(2),
    alt: "Graphic study of an ensemble in side lighting",
    caption: "After hours",
    category: "Ensemble",
  },
];
function Content({
  replay,
  onReplay,
  paused,
  setPaused,
  reduced,
  setReduced,
}: {
  replay: number;
  onReplay: () => void;
  paused: boolean;
  setPaused: (x: boolean) => void;
  reduced: boolean;
  setReduced: (x: boolean) => void;
}) {
  const transition = useStageTransition(),
    [palette, setPalette] = useState(0),
    [scene, setScene] = useState(1),
    [bpm, setBpm] = useState(100),
    [step, setStep] = useState(0),
    [direction, setDirection] = useState<1 | -1>(1),
    [formKey, setFormKey] = useState(0),
    [progress, setProgress] = useState(38);
  const theme = (i: number) => {
    setPalette(i);
    const root = document.documentElement;
    root.setAttribute(
      "data-ng-hl",
      ["jz-ruby", "jz-white", "jz-blue", "jz-pink", "jz-purple"][i],
    );
    root.style.setProperty("--hl", palettes[i][1]);
    root.style.setProperty("--hl-rgb", palettes[i][2]);
  };
  return (
    <>
      <header className="demo-nav">
        <a href="#" className="demo-brand" aria-label="NextGen home">
          <NextGenLogo size={45} animated={false} decorative />
          <span>
            <Shimmer>NEXTGEN</Shimmer>
            <small>Voice Collective</small>
          </span>
        </a>
        <span className="demo-nav-edition">
          NOIR CLUB <i /> MOTION EDITION
        </span>
        <a href="#collection" className="demo-nav-link">
          Explore the collection <span>↘</span>
        </a>
      </header>
      <main>
        <section className="demo-hero" key={`hero-${replay}`}>
          <div className="demo-hero-field">
            <HarmonicField density={14} intensity={0.9} />
          </div>
          <div className="demo-hero-lines" />
          <FilmLayer />
          <div className="demo-hero-content">
            <div className="demo-eyebrow">
              LONDON · AFTER HOURS · EST. NEXTGEN
            </div>
            <h1 id="demo-title">
              <span className="demo-title-small">Extraordinary together.</span>
              <RiseText text="Young voices." delay={80} />
              <NeonText className="demo-hero-neon">One sound.</NeonText>
            </h1>
            <p>
              Old-world atmosphere.
              <br />A new generation of presence.
            </p>
            <div className="demo-hero-actions">
              <NoirButton
                onClick={() =>
                  document
                    .getElementById("collection")
                    ?.scrollIntoView({ behavior: reduced ? "auto" : "smooth" })
                }
              >
                Explore the motion
              </NoirButton>
              <button className="demo-text-button" onClick={onReplay}>
                Replay opening <span>↻</span>
              </button>
            </div>
          </div>
          <div className="demo-medallion">
            <Art className="demo-deco" />
            <NextGenLogo
              size="49%"
              duration={8}
              replayKey={replay}
              decorative
            />
            <span>DRAW · SETTLE · SHIMMER</span>
          </div>
          <div className="demo-hero-footer">
            <span>THE NOIR MOTION COLLECTION / 01</span>
            <span>Move across the waves. Tap to send a ripple.</span>
            <a
              href="#collection"
              aria-label="Scroll to the animation collection"
            >
              ↓
            </a>
          </div>
        </section>
        <div className="demo-controls">
          <div className="demo-colour">
            <span>NEON</span>
            {palettes.map(([label, color], i) => (
              <button
                key={label}
                onClick={() => theme(i)}
                aria-label={`${label} neon`}
                aria-pressed={palette === i}
                style={{ "--swatch": color } as CSSProperties}
              >
                <i />
              </button>
            ))}
            <b>{palettes[palette][0]}</b>
          </div>
          <div className="demo-motion-controls">
            <button aria-pressed={paused} onClick={() => setPaused(!paused)}>
              {paused ? "▶ Resume" : "Ⅱ Pause"}
            </button>
            <button aria-pressed={reduced} onClick={() => setReduced(!reduced)}>
              Reduced motion
            </button>
            <button onClick={onReplay}>↻ Replay</button>
          </div>
        </div>
        <section id="collection" className="demo-section">
          <Reveal>
            <div className="demo-section-heading">
              <div>
                <div className="demo-eyebrow">01 — THE FOUR PILLARS</div>
                <h2>
                  Musicianship,
                  <br />
                  <em>in motion.</em>
                </h2>
              </div>
              <p>
                Engraved silver. Ink-black stages.
                <br />
                One accent, used with intention.
              </p>
            </div>
          </Reveal>
          <div className="demo-pillar-grid">
            {pillars.map(([kind, title, description], i) => (
              <Reveal key={kind} delay={(i % 2) * 100}>
                <article>
                  <PillarCard key={`${kind}-${replay}`} kind={kind} bpm={bpm} />
                  <div className="demo-card-meta">
                    <h3>{kind}</h3>
                    <span>0{i + 1}</span>
                  </div>
                  <h4>{title}</h4>
                  <p>{description}</p>
                  {kind === "precision" && (
                    <label className="demo-tempo-control">
                      Tempo{" "}
                      <input
                        type="range"
                        min="60"
                        max="140"
                        step="5"
                        value={bpm}
                        onChange={(e) => setBpm(+e.target.value)}
                      />
                      <output>{bpm} BPM</output>
                    </label>
                  )}
                </article>
              </Reveal>
            ))}
          </div>
        </section>
        <Marquee
          items={["Blend", "Harmony", "Precision", "Presence", "One sound"]}
        />
        <section className="demo-section demo-neon-section">
          <Reveal>
            <div className="demo-eyebrow">02 — LIGHT, NOT JUST COLOUR</div>
            <h2>
              A little electricity.
              <br />
              <em>A lot of atmosphere.</em>
            </h2>
            <p>
              Reflected glass highlights, a warm ignition and light that spills
              onto the wall. Change the neon colour above to see the entire
              system respond.
            </p>
            <NoirButton variant="outline" onClick={onReplay}>
              Reignite the signs
            </NoirButton>
          </Reveal>
          <div className="demo-neon-plate" key={`plate-${replay}`}>
            <span className="demo-screw a" />
            <span className="demo-screw b" />
            <span className="demo-screw c" />
            <span className="demo-screw d" />
            <div className="demo-sign-label">LIVE AT THE</div>
            <NeonText>Noir Club</NeonText>
            <div className="demo-sign-rule" />
            <span className="demo-sign-small">
              YOUNG VOICES. TIMELESS SOUL.
            </span>
          </div>
        </section>
        <section className="demo-section demo-transition-section">
          <div className="demo-section-heading">
            <div>
              <div className="demo-eyebrow">03 — BETWEEN THE SCENES</div>
              <h2>
                Every entrance
                <br />
                <em>deserves a curtain.</em>
              </h2>
            </div>
            <p>
              Two velvet panels close, the scene changes,
              <br />
              and the next movement is revealed.
            </p>
          </div>
          <div className="demo-transition-stage">
            <Art className="demo-stage-art" />
            <div>
              <span className="demo-eyebrow">
                ACT {String(scene).padStart(2, "0")}
              </span>
              <h3 id="demo-act-title" tabIndex={-1}>
                {
                  ["The overture.", "The collective.", "The encore."][
                    (scene - 1) % 3
                  ]
                }
              </h3>
              <NeonText intensity="inline">Take your place.</NeonText>
              <div className="demo-button-row">
                <NoirButton
                  onClick={() =>
                    void transition(
                      () => setScene((s) => s + 1),
                      () => document.getElementById("demo-act-title"),
                    )
                  }
                >
                  Play curtain transition
                </NoirButton>
                <NoirButton variant="neon" onClick={onReplay}>
                  Replay the lights
                </NoirButton>
              </div>
            </div>
          </div>
        </section>
        <section className="demo-section">
          <div className="demo-section-heading">
            <div>
              <div className="demo-eyebrow">04 — THE CONTACT SHEET</div>
              <h2>
                Moments worth
                <br />
                <em>holding onto.</em>
              </h2>
            </div>
            <p>
              Filter, open, swipe or use the arrow keys.
              <br />
              Illustrative stage studies for this demo.
            </p>
          </div>
          <NoirGallery items={images} />
        </section>
        <section className="demo-section demo-form-section">
          <div>
            <div className="demo-eyebrow">05 — SMALL MOMENTS MATTER</div>
            <h2>
              Make the next
              <br />
              <em>step feel effortless.</em>
            </h2>
            <p>
              Directional step changes, a quiet progress line and a neon
              thank-you. This is a motion demonstration; it does not submit an
              application.
            </p>
            <label className="demo-upload-control">
              Upload animation preview{" "}
              <input
                type="range"
                min="0"
                max="100"
                value={progress}
                onChange={(e) => setProgress(+e.target.value)}
              />
            </label>
            <UploadProgress
              fileName="audition-film.mp4"
              progress={progress}
              status={progress === 100 ? "complete" : "uploading"}
            />
          </div>
          <div className="demo-form-card">
            <StepProgress
              steps={["Singer", "Guardian", "Voice", "Finish"]}
              current={Math.min(step, 3)}
            />
            {step < 4 ? (
              <>
                <StepPanel key={formKey} step={step} direction={direction}>
                  <div className="demo-eyebrow">STEP 0{step + 1}</div>
                  <h3>
                    {
                      [
                        "Your moment starts here.",
                        "A little support.",
                        "Tell us about your voice.",
                        "Ready for the spotlight.",
                      ][step]
                    }
                  </h3>
                  <p>
                    {
                      [
                        "A clean entrance. Space to focus.",
                        "Keep the transitions calm and the next step clear.",
                        "The animation frames the content without competing with it.",
                        "A final reveal brings the sequence to a close.",
                      ][step]
                    }
                  </p>
                  <div className="demo-form-ornament">✦</div>
                </StepPanel>
                <div className="demo-button-row">
                  <NoirButton
                    variant="ghost"
                    disabled={step === 0}
                    onClick={() => {
                      setDirection(-1);
                      setStep((s) => s - 1);
                    }}
                  >
                    Back
                  </NoirButton>
                  <NoirButton
                    onClick={() => {
                      setDirection(1);
                      setStep((s) => s + 1);
                    }}
                  >
                    {step === 3 ? "Preview success" : "Next step"}
                  </NoirButton>
                </div>
              </>
            ) : (
              <>
                <SuccessMoment>Your next movement is waiting.</SuccessMoment>
                <button
                  className="demo-text-button"
                  onClick={() => {
                    setStep(0);
                    setFormKey((k) => k + 1);
                  }}
                >
                  Replay sequence ↻
                </button>
              </>
            )}
          </div>
        </section>
        <footer className="demo-footer">
          <Shimmer>NEXTGEN</Shimmer>
          <NeonText intensity="inline">See you in the spotlight.</NeonText>
          <span>NOIR CLUB · REACT + TYPESCRIPT · MOTION COLLECTION</span>
        </footer>
      </main>
      <NextGenPianoRail />
      <div className="demo-piano-hint">
        Open the piano · enable sound to play
      </div>
    </>
  );
}
export function App() {
  const [replay, setReplay] = useState(0),
    [paused, setPaused] = useState(false),
    [reduced, setReduced] = useState(false);
  return (
    <NoirMotionProvider paused={paused} reducedMotion={reduced}>
      <StageCurtain>
        <Content
          replay={replay}
          onReplay={() => setReplay((x) => x + 1)}
          paused={paused}
          setPaused={setPaused}
          reduced={reduced}
          setReduced={setReduced}
        />
      </StageCurtain>
    </NoirMotionProvider>
  );
}
