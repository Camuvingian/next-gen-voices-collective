"use client";
import { useEffect, useRef, useState, type CSSProperties } from "react";
import { createPianoEngine } from "./pianoEngine";
export interface NextGenPianoRailProps {
  open?: boolean;
  defaultOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
  showToggle?: boolean;
  showSoundButton?: boolean;
  persistKey?: string;
  baseMidi?: number;
  keyHeight?: number;
  scrollTriad?: boolean;
  pushContent?: boolean;
}
const whites = [0, 2, 4, 5, 7, 9, 11],
  names = ["C", "D", "E", "F", "G", "A", "B"];
export function NextGenPianoRail({
  open: controlled,
  defaultOpen = false,
  onOpenChange,
  showToggle = true,
  showSoundButton = true,
  persistKey,
  baseMidi = 48,
  keyHeight = 30,
  scrollTriad = true,
  pushContent = false,
}: NextGenPianoRailProps) {
  const [internal, setInternal] = useState(defaultOpen),
    [sound, setSound] = useState(false),
    [pressed, setPressed] = useState<number[]>([]),
    [lead, setLead] = useState(0),
    [count, setCount] = useState(20);
  const open = controlled ?? internal,
    engine = useRef<ReturnType<typeof createPianoEngine> | null>(null),
    down = useRef(false),
    held = useRef<number | null>(null),
    rail = useRef<HTMLElement>(null),
    lastStrike = useRef(0),
    error = useRef(false);
  const [audioError, setAudioError] = useState("");
  const midi = (i: number) => baseMidi + Math.floor(i / 7) * 12 + whites[i % 7];
  function play(note: number) {
    if (!sound) return;
    try {
      engine.current ??= createPianoEngine();
      engine.current.noteOn(note);
    } catch {
      if (!error.current) {
        error.current = true;
        setAudioError("Audio is unavailable in this browser.");
      }
      setSound(false);
    }
  }
  function release() {
    down.current = false;
    held.current = null;
    engine.current?.allOff();
    setPressed([]);
  }
  function toggle() {
    const value = !open;
    setInternal(value);
    onOpenChange?.(value);
    if (persistKey)
      try {
        localStorage.setItem(persistKey, String(value));
      } catch {}
  }
  useEffect(() => {
    if (persistKey && controlled === undefined)
      try {
        const v = localStorage.getItem(persistKey);
        if (v !== null) setInternal(v === "true");
      } catch {}
  }, [persistKey, controlled]);
  useEffect(() => {
    const size = () =>
      setCount(Math.max(7, Math.floor((innerHeight - 130) / keyHeight)));
    size();
    window.addEventListener("resize", size);
    return () => window.removeEventListener("resize", size);
  }, [keyHeight]);
  useEffect(() => () => engine.current?.dispose(), []);
  useEffect(() => {
    const stop = () => release();
    window.addEventListener("pointerup", stop);
    window.addEventListener("pointercancel", stop);
    window.addEventListener("blur", stop);
    document.addEventListener("visibilitychange", stop);
    return () => {
      window.removeEventListener("pointerup", stop);
      window.removeEventListener("pointercancel", stop);
      window.removeEventListener("blur", stop);
      document.removeEventListener("visibilitychange", stop);
    };
  }, []);
  useEffect(() => {
    if (!open) {
      release();
      return;
    }
    let raf = 0;
    const scroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const p =
          scrollY /
          Math.max(1, document.documentElement.scrollHeight - innerHeight);
        setLead(Math.round(p * Math.max(0, count - 5)));
      });
    };
    window.addEventListener("scroll", scroll, { passive: true });
    scroll();
    return () => {
      window.removeEventListener("scroll", scroll);
      cancelAnimationFrame(raf);
    };
  }, [open, count]);
  useEffect(() => {
    if (
      !open ||
      !sound ||
      !scrollTriad ||
      performance.now() - lastStrike.current < 326
    )
      return;
    lastStrike.current = performance.now();
    const phase = Math.floor(lead / Math.max(1, count / 3));
    const voicing = [
      [50, 53, 57, 60, 64],
      [43, 53, 59, 64, 69],
      [48, 55, 59, 62, 64],
    ][Math.min(2, phase)];
    voicing.forEach((n) => play(n));
  }, [lead]);
  useEffect(() => {
    const root = document.documentElement;
    const previous = root.getAttribute("data-ngp-open");
    root.setAttribute("data-ngp-open", String(open));
    if (pushContent) root.setAttribute("data-ngp-push", "true");
    return () => {
      if (previous === null) root.removeAttribute("data-ngp-open");
      else root.setAttribute("data-ngp-open", previous);
      if (pushContent) root.removeAttribute("data-ngp-push");
    };
  }, [open, pushContent]);
  const strike = (note: number) => {
    if (held.current !== null) engine.current?.noteOff(held.current);
    held.current = note;
    setPressed([note]);
    play(note);
  };
  return (
    <>
      {showToggle && (
        <button
          className="nm-piano-toggle"
          type="button"
          onClick={toggle}
          aria-pressed={open}
          aria-label={open ? "Close piano" : "Open piano"}
        >
          ♮ <span>{open ? "Close" : "Piano"}</span>
        </button>
      )}
      <aside
        ref={rail}
        className="nm-piano"
        data-open={open}
        aria-label="Playable piano"
        inert={!open}
        style={{ "--ngp-key-height": `${keyHeight}px` } as CSSProperties}
        onKeyDown={(e) => {
          if (
            e.repeat ||
            e.altKey ||
            e.ctrlKey ||
            e.metaKey ||
            !e.target ||
            !(e.target as Element).closest(".nm-piano-keys")
          )
            return;
          const i = "asdfghjkl".indexOf(e.key.toLowerCase());
          if (i >= 0) {
            e.preventDefault();
            strike(midi(i));
          }
        }}
        onKeyUp={release}
      >
        <div className="nm-piano-head">N/G</div>
        <div className="nm-piano-keys">
          {Array.from({ length: count }, (_, i) => {
            const n = midi(i),
              black = ![2, 6].includes(i % 7);
            return (
              <div className="nm-piano-keyrow" key={i}>
                <button
                  type="button"
                  className="nm-key nm-key-white"
                  data-lit={
                    pressed.includes(n) ||
                    (scrollTriad && [lead, lead + 2, lead + 4].includes(i))
                  }
                  aria-label={`${names[i % 7]}${Math.floor(n / 12) - 1}`}
                  onPointerDown={(e) => {
                    e.preventDefault();
                    e.currentTarget.focus();
                    down.current = true;
                    strike(n);
                  }}
                  onPointerEnter={() => {
                    if (down.current) strike(n);
                  }}
                  onClick={(e) => {
                    if (e.detail === 0) {
                      play(n);
                      setPressed([n]);
                    }
                  }}
                  onBlur={release}
                >
                  <span>
                    {names[i % 7]}
                    {i % 7 === 0 ? Math.floor(n / 12) - 1 : ""}
                  </span>
                </button>
                {black && i < count - 1 && (
                  <button
                    type="button"
                    className="nm-key nm-key-black"
                    data-lit={pressed.includes(n + 1)}
                    aria-label={`${names[i % 7]} sharp ${Math.floor(n / 12) - 1}`}
                    onPointerDown={(e) => {
                      e.preventDefault();
                      e.currentTarget.focus();
                      down.current = true;
                      strike(n + 1);
                    }}
                    onPointerEnter={() => {
                      if (down.current) strike(n + 1);
                    }}
                    onClick={(e) => {
                      if (e.detail === 0) play(n + 1);
                    }}
                    onBlur={release}
                  />
                )}
              </div>
            );
          })}
        </div>
        {showSoundButton && (
          <button
            type="button"
            className="nm-piano-sound"
            aria-pressed={sound}
            onClick={() => {
              if (sound) {
                setSound(false);
                engine.current?.allOff();
              } else {
                try {
                  engine.current ??= createPianoEngine();
                  engine.current.noteOn(60, 0.4);
                  setSound(true);
                } catch {
                  setAudioError("Audio unavailable");
                }
              }
            }}
          >
            {sound ? "Sound on" : "Sound off"}
          </button>
        )}
        <span role="status" className="nm-sr">
          {audioError}
        </span>
      </aside>
    </>
  );
}
export const PianoRail = NextGenPianoRail;
