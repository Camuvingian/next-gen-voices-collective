/** Original additive electric-piano timbre; no recordings or third-party soundfonts. */
export function createPianoEngine() {
  let context: AudioContext | null = null;
  const voices = new Map<number, { nodes: OscillatorNode[]; gain: GainNode }>();
  function noteOff(midi: number) {
    const v = voices.get(midi);
    if (!v || !context) return;
    const t = context.currentTime;
    v.gain.gain.cancelScheduledValues(t);
    v.gain.gain.setTargetAtTime(0, t, 0.07);
    v.nodes.forEach((o) => o.stop(t + 0.45));
    voices.delete(midi);
  }
  function allOff() {
    [...voices.keys()].forEach(noteOff);
  }
  function noteOn(midi: number, velocity = 0.6) {
    context ??= new AudioContext();
    void context.resume();
    noteOff(midi);
    if (voices.size >= 16) noteOff(voices.keys().next().value!);
    const ctx = context,
      t = ctx.currentTime,
      gain = ctx.createGain(),
      freq = 440 * 2 ** ((midi - 69) / 12);
    gain.connect(ctx.destination);
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(
      Math.max(0, Math.min(1, velocity)) ** 2 * 0.15,
      t + 0.007,
    );
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 4);
    const nodes = [1, 2, 3.995, 6.01].map((ratio, i) => {
      const o = ctx.createOscillator(),
        a = ctx.createGain();
      o.type = "sine";
      o.frequency.value = freq * ratio;
      a.gain.value = [1, 0.3, 0.08, 0.025][i];
      o.connect(a);
      a.connect(gain);
      o.start(t);
      o.stop(t + 4.5);
      o.onended = () => {
        o.disconnect();
        a.disconnect();
        if (i === 0) {
          if (voices.get(midi)?.gain === gain) voices.delete(midi);
          gain.disconnect();
        }
      };
      return o;
    });
    voices.set(midi, { nodes, gain });
  }
  return {
    noteOn,
    noteOff,
    allOff,
    dispose() {
      allOff();
      void context?.close();
      context = null;
    },
  };
}
