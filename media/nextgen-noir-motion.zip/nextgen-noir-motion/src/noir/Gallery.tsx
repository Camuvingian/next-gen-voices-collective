"use client";
import { useEffect, useRef, useState } from "react";
export interface GalleryItem {
  id: string;
  src: string;
  alt: string;
  caption: string;
  category: string;
}
export function NoirGallery({ items }: { items: GalleryItem[] }) {
  const [filter, setFilter] = useState("All"),
    [index, setIndex] = useState<number | null>(null),
    dialog = useRef<HTMLDialogElement>(null),
    origin = useRef<HTMLElement | null>(null),
    x = useRef(0);
  const visible =
      filter === "All" ? items : items.filter((i) => i.category === filter),
    current = index === null ? null : visible[index];
  const close = () => {
    setIndex(null);
    dialog.current?.close();
    origin.current?.focus();
  };
  const advance = (n: number) =>
    setIndex((i) =>
      i === null ? null : (i + n + visible.length) % visible.length,
    );
  useEffect(() => {
    if (current && !dialog.current?.open) dialog.current?.showModal();
    if (!current) dialog.current?.close();
  }, [current]);
  useEffect(() => {
    if (index === null) return;
    for (const delta of [-1, 1]) {
      const src =
        visible[(index + delta + visible.length) % visible.length]?.src;
      if (src) {
        const img = new Image();
        img.src = src;
      }
    }
  }, [index, filter, items]);
  return (
    <div className="nm-gallery">
      <div className="nm-gallery-filters" aria-label="Gallery filters">
        {["All", ...new Set(items.map((i) => i.category))].map((cat) => (
          <button
            type="button"
            key={cat}
            aria-pressed={cat === filter}
            onClick={() => {
              setFilter(cat);
              setIndex(null);
            }}
          >
            {cat}
          </button>
        ))}
      </div>
      <div className="nm-gallery-grid" key={filter}>
        {visible.map((item, i) => (
          <button
            type="button"
            key={item.id}
            className="nm-gallery-tile"
            style={{ animationDelay: `${i * 45}ms` }}
            onClick={(e) => {
              origin.current = e.currentTarget;
              setIndex(i);
            }}
          >
            <img src={item.src} alt={item.alt} loading="lazy" />
            <span>
              {item.caption} <i aria-hidden="true">↗</i>
            </span>
          </button>
        ))}
      </div>
      <dialog
        ref={dialog}
        className="nm-lightbox"
        onCancel={(e) => {
          e.preventDefault();
          close();
        }}
        onClick={(e) => {
          if (e.target === dialog.current) close();
        }}
        onKeyDown={(e) => {
          if (e.key === "ArrowRight") {
            e.preventDefault();
            advance(1);
          }
          if (e.key === "ArrowLeft") {
            e.preventDefault();
            advance(-1);
          }
        }}
        aria-label="Image viewer"
      >
        <div className="nm-lightbox-inner">
          <button
            className="nm-lightbox-close"
            type="button"
            onClick={close}
            autoFocus
          >
            Close ×
          </button>
          {current && (
            <>
              <img
                key={current.id}
                src={current.src}
                alt={current.alt}
                onPointerDown={(e) => {
                  x.current = e.clientX;
                }}
                onPointerUp={(e) => {
                  const delta = e.clientX - x.current;
                  if (Math.abs(delta) > 60) advance(delta < 0 ? 1 : -1);
                }}
              />
              <div className="nm-lightbox-bar">
                <button
                  type="button"
                  onClick={() => advance(-1)}
                  aria-label="Previous image"
                >
                  ←
                </button>
                <span role="status">
                  {current.caption} / {(index ?? 0) + 1} of {visible.length}
                </span>
                <button
                  type="button"
                  onClick={() => advance(1)}
                  aria-label="Next image"
                >
                  →
                </button>
              </div>
            </>
          )}
        </div>
      </dialog>
    </div>
  );
}
