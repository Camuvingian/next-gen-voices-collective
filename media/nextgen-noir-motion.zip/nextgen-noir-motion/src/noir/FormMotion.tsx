"use client";
import { useEffect, useRef, type ReactNode, type CSSProperties } from "react";
import { NeonText } from "./Typography";
export function StepProgress({
  steps,
  current,
}: {
  steps: string[];
  current: number;
}) {
  return (
    <ol className="nm-steps" aria-label="Application progress">
      {steps.map((label, i) => (
        <li
          key={label}
          data-complete={i < current}
          aria-current={i === current ? "step" : undefined}
        >
          <span className="nm-step-line">
            <i />
          </span>
          <span>
            {String(i + 1).padStart(2, "0")} / {label}
          </span>
        </li>
      ))}
    </ol>
  );
}
export function StepPanel({
  children,
  step,
  direction = 1,
}: {
  children: ReactNode;
  step: string | number;
  direction?: 1 | -1;
}) {
  const ref = useRef<HTMLDivElement>(null),
    first = useRef(true);
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    ref.current?.focus({ preventScroll: true });
  }, [step]);
  return (
    <div
      key={step}
      ref={ref}
      className="nm-step-panel"
      tabIndex={-1}
      style={{ "--nm-direction": direction } as CSSProperties}
    >
      {children}
    </div>
  );
}
/** Controlled visual only: progress must come from the host's upload transport. */
export function UploadProgress({
  fileName,
  progress,
  status,
  error,
  onRetry,
}: {
  fileName: string;
  progress: number;
  status: "uploading" | "complete" | "error";
  error?: string;
  onRetry?: () => void;
}) {
  return (
    <div className="nm-upload" data-status={status}>
      <span>{fileName}</span>
      <strong>
        {status === "error"
          ? "Upload failed"
          : status === "complete"
            ? "Ready"
            : `${Math.round(progress)}%`}
      </strong>
      <progress
        max={100}
        value={Math.max(0, Math.min(100, progress))}
        aria-label={`Upload ${fileName}`}
      />
      <span role={status === "error" ? "alert" : "status"}>
        {status === "error"
          ? error
          : status === "complete"
            ? "Upload complete"
            : "Uploading…"}
      </span>
      {status === "error" && onRetry && (
        <button type="button" onClick={onRetry}>
          Retry upload
        </button>
      )}
    </div>
  );
}
export function SuccessMoment({
  title = "Thank you.",
  children,
}: {
  title?: string;
  children?: ReactNode;
}) {
  return (
    <div className="nm-success" role="status">
      <svg viewBox="0 0 80 80" aria-hidden="true">
        <circle cx="40" cy="40" r="34" />
        <path d="M23 40L35 52L58 28" pathLength="1" />
      </svg>
      <NeonText intensity="inline">{title}</NeonText>
      <p>{children}</p>
    </div>
  );
}
