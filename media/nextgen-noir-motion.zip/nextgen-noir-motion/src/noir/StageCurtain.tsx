"use client";
import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { NextGenLogo } from "./NextGenLogo";
import { useMotion } from "./motion";
type Transition = (
  commit: () => void | Promise<void>,
  focus?: () => HTMLElement | null,
) => Promise<void>;
const Stage = createContext<Transition>(async (commit) => {
  await commit();
});
export const useStageTransition = () => useContext(Stage);
/** Framework-neutral. commit must resolve when the destination content has mounted. */
export function StageCurtain({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null),
    m = useMotion(ref),
    [phase, setPhase] = useState("idle"),
    busy = useRef(false),
    alive = useRef(true);
  const waits = useRef(new Map<ReturnType<typeof setTimeout>, () => void>());
  const policy = useRef(m);
  policy.current = m;
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
      waits.current.forEach((resolve, id) => {
        clearTimeout(id);
        resolve();
      });
      waits.current.clear();
    };
  }, []);
  const sleep = (ms: number) =>
    new Promise<void>((resolve) => {
      const id = setTimeout(() => {
        waits.current.delete(id);
        resolve();
      }, ms);
      waits.current.set(id, resolve);
    });
  const transition: Transition = async (commit, focus) => {
    if (busy.current) return;
    busy.current = true;
    try {
      if (!policy.current.reduced && !policy.current.paused) {
        setPhase("cover");
        await sleep(540);
      }
      if (!alive.current) return;
      await commit();
      await sleep(32);
      if (!alive.current) return;
      if (!policy.current.reduced && !policy.current.paused) {
        setPhase("reveal");
        await sleep(680);
      }
      if (alive.current) {
        setPhase("idle");
        const target = focus?.();
        if (target) {
          if (!target.hasAttribute("tabindex")) target.tabIndex = -1;
          target.focus({ preventScroll: true });
        }
      }
    } finally {
      busy.current = false;
      if (alive.current) setPhase("idle");
    }
  };
  return (
    <Stage.Provider value={transition}>
      {children}
      <div
        ref={ref}
        className="nm-curtain"
        data-phase={phase}
        aria-hidden="true"
      >
        <div className="nm-curtain-panel nm-curtain-left" />
        <div className="nm-curtain-panel nm-curtain-right" />
        <div className="nm-curtain-mark">
          <NextGenLogo
            size={108}
            duration={1.7}
            replayKey={phase === "cover" ? "draw" : "hold"}
            animated={phase === "cover"}
            decorative
          />
          <span>THE NEXT MOVEMENT</span>
        </div>
      </div>
    </Stage.Provider>
  );
}
