# Integrate the NextGen Noir Motion Collection

You are working in the existing NextGen Voice Collective React + TypeScript application. Inspect the repository and its local instructions before editing. This directory contains the actual animation source and a working reference preview, not just design instructions.

## Goal

Upgrade the existing Noir Club animations using `src/noir/` from this package. Preserve the site's content, approved Interlock logo geometry, routes, data handling and existing functionality. Match the 1920s–30s Noir art direction in `dist/nextgen-noir-preview.html`: black lacquer, engraved silver, ivory typography, oxblood waves and one themeable neon highlight. The showroom's layout is reference material, not a replacement for the production site.

## Start here

1. Read `README.md`, including the scope limits, token mapping, piano sound and routing contract.
2. Open `dist/nextgen-noir-preview.html` and exercise its controls.
3. Identify the application's existing `HarmonicField`, `NeonDirector`, `JazzGlyph`/`PillarCard`, `NextGenLogo`, `PianoRail`, reveal utilities, curtain/router, gallery and form implementations. The supplied source and prompt numbering differ; locate files by symbol rather than number.
4. Copy this package's `src/noir/` to a suitable component directory. Keep its internal relative imports. Use the app's existing React installation; do not replace its package manifest with this demo's manifest.
5. Import `tokens.css` before existing app theme tokens; import `logo.css` and `noir.css` once. Do not import `src/demo/demo.css` into production.
6. Mount `NoirMotionProvider` once around the client app. For Next.js, keep the provider in a client boundary and global CSS in the root layout.

## Map the existing features

| Existing feature | Replacement or integration |
|---|---|
| `HarmonicField` | New `HarmonicField`; retain correct containing height and layered hero positioning |
| NeonDirector/class-driven sign | Explicit `NeonText` around string text; remove the old controller for those elements to avoid double flickering |
| CSS wordmark sheen | `Shimmer`, with the existing display type and correct aria label |
| `RiseText` / `Reveal` | New equivalents; delay values are milliseconds |
| `JazzGlyph kind=...` / Noir pillar | `PillarCard kind=...`; preserve the surrounding title/body copy |
| Interlock mark | New `NextGenLogo`; its original two path strings are unchanged and the hollow space is transparent |
| Curtain | `StageCurtain` and `useStageTransition`; wire to the actual router as described below |
| Piano rail | `NextGenPianoRail`; named props from the brief are present, but its sound is synthesised rather than sampled |
| Marquee | New `Marquee`; keep the site's semantic text items |
| Film grain | One locally bounded `FilmLayer` per intended stage; remove redundant old overlays |
| Buttons | Port `.nm-button` treatment onto the site's existing semantic Button/Link API, or use `NoirButton` for actions |
| Gallery | Keep production video/media logic. Use `NoirGallery` directly for image-only galleries, or transplant the motion and dialog behaviour into the existing media component |
| Application flow | Wrap existing content in `StepPanel`, drive `StepProgress` and `UploadProgress` from real state, show `SuccessMoment` only after real submission success |

## Important integration details

- Keep the production application and its business logic. Never replace a real uploader with the demo's slider or make a local success animation claim a submission succeeded.
- Theme with `--hl` and `--hl-rgb`. Keep `--ng-glow`, `--ng-glow-2` and the logo's accent variables independently brand-red unless the user wants them linked.
- The preview changes CSS variables directly for demonstration. In the app, reuse its existing palette selector and root attributes.
- Avoid retaining both old and new CSS animation rules on the same nodes.
- Preserve the original logo path data exactly; do not add musical notes to the mark or redesign the silhouette.
- The new field is a lightweight Canvas2D renderer. Do not describe it as a Three.js/R3F/WebGL implementation. If the application specifically requires its original shader renderer, retain that renderer and port the conductor/ripple behaviour separately.
- Give wave fields a bounded height. Canvas itself is absolutely positioned and does not size its parent.
- The piano is opt-in audio and has no samples. If a sampled acoustic grand is required, replace the engine with an explicitly licensed sample set and include attribution; do not silently reuse the flagged soundfont.
- Use one rail instance per document. Choose a C MIDI note for `baseMidi` so key names and black-key placement remain correct.
- Preserve native anchors for navigation. `NoirButton` is a button; do not use it as a fake link or wrap interactive controls inside one another.
- Use the installed Limelight, Yellowtail and Jost fonts, or self-host the included files with their notices.

## Router contract

Mount `StageCurtain` above route boundaries. Its transition callback runs after the panels have covered the viewport and must resolve only when destination content has mounted. Next App Router's `router.push` does not return a navigation-completion promise. Build an adapter that resolves from a pathname/content-mounted effect, or use the app's existing navigation-completion mechanism. Preserve normal modified-click/new-tab link behaviour. Handle back/forward using the router's supported API rather than ad hoc global history overrides.

Keep the current page available on navigation failure. Catch transition errors, show the application's error state and release the transition. Focus the destination h1 after reveal. Never delay actual submission or critical validation just for an animation.

## Verification

Run the project's existing type checks/build. Verify narrow and wide layouts, keyboard navigation and reduced motion. Test multiple logos/cards on the same page for SVG ID collisions, palette changes while moving and paused, route failures, rapid repeat clicks, back/forward, gallery Escape/focus restoration, audio opt-in, piano release outside the rail, and cleanup on unmount. Check actual iOS Safari and target-device performance before claiming specific frame-rate or audio-latency numbers.

Deliver a concise summary of replacements, any retained integrations and the checks you actually ran. Do not claim that optional features in the original brief (Mux upload, sampled grand, Web MIDI, FLIP/shared elements, Lottie exports) were implemented by this package.
