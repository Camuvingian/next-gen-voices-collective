# NextGen Noir Motion Collection

A coordinated React + TypeScript animation kit based on your NextGen Noir Club prototype: 1920s–30s Art Deco, black lacquer, engraved silver, ivory, deep-red voice ribbons and a single changeable neon accent.

## Give this to Claude

Open `CLAUDE_IMPLEMENTATION_PROMPT.md`, paste its contents into Claude Code (or a Claude session with repository access), and point it to this extracted folder and your website repository. The prompt directs Claude to implement the supplied components in the actual site.

## See it immediately

Open `dist/nextgen-noir-preview.html` in a browser. It is a self-contained file with bundled React, fonts, CSS and illustrations. It makes no network requests and needs no server. If your file viewer suppresses scripts, download it and open it in Chrome, Edge, Firefox or Safari.

The compact conversation preview is also included at `dist/nextgen-noir-compact-preview.html`.

The full demo includes five colour presets, replay, pause, reduced motion, tempo control, a curtain transition, a playable piano, gallery filters/lightbox and an application-motion sequence. The piano is muted until you open it and explicitly enable sound.

## Use in an existing React app

Copy `src/noir/` into your app, retaining the relative imports. React is the only runtime dependency. The package is built and type-checked with React 19.2 and strict TypeScript 5.9.

Import the styles once in your app entry or Next.js root layout:

```tsx
import './noir/tokens.css'; // defaults; import your existing theme after this
import './theme/tokens.css'; // optional: your existing site tokens
import './theme/jazz.css'; // optional: existing Noir palette overrides
import './noir/logo.css';
import './noir/noir.css';
```

Do **not** copy `src/demo/demo.css` into an existing site. It is only the showroom layout.

```tsx
'use client';
import {
  NoirMotionProvider, HarmonicField, NeonText,
  PillarCard, NextGenLogo, NoirButton,
} from './noir';

export function Hero() {
  return (
    <NoirMotionProvider>
      <section style={{ position: 'relative', isolation: 'isolate' }}>
        <HarmonicField density={12} intensity={0.9} />
        <NextGenLogo size={128} />
        <h1>Young voices. <NeonText>One sound.</NeonText></h1>
        <NoirButton onClick={() => { /* your action */ }}>Apply to audition</NoirButton>
      </section>
      <PillarCard kind="blend" />
      <PillarCard kind="harmony" />
      <PillarCard kind="precision" bpm={100} />
      <PillarCard kind="presence" />
    </NoirMotionProvider>
  );
}
```

Use one provider around the site. Components work individually, but the provider supplies shared palette aliases and the optional global pause/reduced-motion controls. For a background field, position its wrapper absolutely, give it a real height, and place text above it. Leave exposed areas pointer-interactive for conducting and tap ripples.

## Components

| Export | Behaviour / important props |
|---|---|
| `NoirMotionProvider` | `paused`, `reducedMotion`; the OS reduced-motion preference always wins |
| `HarmonicField` | Four layered voices, eased conducting, velocity energy, tap ripples, major/minor breathing; `density`, `intensity`, `interactive`, `className` |
| `NeonText` | Selectable glass/neon text, wall spill, warm ignition and occasional gentle dips; string children, `as`, `intensity`, `flicker`, `replayKey` |
| `Shimmer` | Narrow chrome reflection over text; `interval` and `delay` in seconds |
| `RiseText` | Masked, staggered word entrance; `text`, `delay` and `stagger` in milliseconds |
| `Reveal` | Reveal below-fold content; initial viewport content stays visible; `delay` in milliseconds |
| `PillarCard` | `kind="blend\|harmony\|precision\|presence"`; optional `bpm` |
| `BlendCard`, `HarmonyCard`, `PrecisionCard`, `PresenceCard` | Named convenience exports |
| `NextGenLogo` | Original approved geometry and sequence, with transparent hollow strokes; existing props retained |
| `StageCurtain`, `useStageTransition` | Twin velvet panels and logo; callback-driven route/content swap |
| `FilmLayer` | Locally bounded grain and vignette; `intensity` from 0 to 0.12 |
| `Marquee` | Measured repeated content, no empty tail; `items`, `speed` (cycle seconds), `direction`, `pauseOnHover` |
| `NoirButton` | Magnetic pointer response, rising fill, pressed state; `primary`, `outline`, `neon`, `ghost` |
| `NextGenPianoRail` / `PianoRail` | Playable ivory keyboard, scroll voicings, opt-in synthesised sound |
| `NoirGallery` | Image filters, entrance motion, native modal lightbox, keyboard navigation, swipe and neighbour preloading |
| `StepProgress`, `StepPanel` | Controlled progress and direction-aware step entrance; hook into your existing form |
| `UploadProgress` | Controlled view of real transport state; no upload implementation |
| `SuccessMoment` | Drawn tick and neon thank-you |

## Live theming

The existing tokens are retained. Set both colour formats together:

```css
:root[data-ng-hl="jz-blue"] {
  --hl: #69cfff;
  --hl-rgb: 105, 207, 255;
}
```

```ts
document.documentElement.dataset.ngHl = 'jz-blue';
```

`--hl` / `--hl-rgb` control neon, card accents, keys and controls. The logo and waves remain brand-red by default, as specified in your brief. Change these separately to recolour them:

```css
:root {
  --ng-glow: 222, 24, 44;
  --ng-glow-2: 128, 10, 24;
  --ng-edge: #a30f1d;
  --ng-secondary: #5a0611;
  --ng-accent: #ff3446;
  --ng-shine: #ffd6da;
}
```

The Canvas field re-reads inherited colours when ancestor `style`, `class`, `data-ng-hl` or `data-ng-theme` attributes change, including while paused. It does not restart its clock. `--ng-surface` remains accepted by the logo theme type for source compatibility but is no longer needed: the hollow area is a real SVG mask.

Font variables: `--font-display`, `--font-script`, `--font-sans`. Limelight, Yellowtail and Jost are included under `fonts/` with their license notices. Your existing site already loads these. To self-host them, copy the font files and adjust the URLs from `src/demo/fonts.css` to your asset layout.

## Routing

```tsx
<NoirMotionProvider>
  <StageCurtain><App /></StageCurtain>
</NoirMotionProvider>
```

Inside the provider:

```tsx
const transition = useStageTransition();
await transition(
  async () => {
    // Commit your route or local scene here, while the curtain is closed.
    // Resolve only once the new page's content has actually mounted.
    await navigateAndWaitForPage();
  },
  () => document.querySelector<HTMLElement>('main h1'),
);
```

The animation takes about 1.25 seconds plus the destination load time. This is a framework-neutral primitive, **not** a pre-wired Next.js router interceptor. Next App Router's `router.push()` returns void: do not pretend awaiting it waits for the next page. Resolve a navigation promise from a pathname/content-mounted effect, and wire back/forward separately if desired. Keep the provider above route boundaries. Errors reject the promise and release the curtain; the application owns its error UI.

## Piano

Existing named rail props are available: `open`, `defaultOpen`, `onOpenChange`, `showToggle`, `showSoundButton`, `persistKey`, `baseMidi`, `keyHeight`, `scrollTriad`, `pushContent`. One rail instance per document is supported because it owns the `data-ngp-open` attribute.

Click/touch keys, drag for a glissando, or focus a key and use A–L for the first nine white keys. Enter/Space activates focused key buttons. Sound requires the Sound button. With sound enabled, scrolling triggers a Dm9 → G13 → Cmaj9 palette, rate-limited to approximately an eighth note at 92 BPM. It is a simple progression selection, not a full sequencer or MIDI implementation.

The sound is an original additive electric-piano-like patch, tuned with `440 * 2 ** ((midi - 69) / 12)`. There are no GPL soundfonts, external samples or audio downloads. It is not a sampled acoustic grand. `baseMidi` defaults to C3 (48); use a C note as the base to preserve the white/black key naming and pattern.

## Motion and performance

- Canvas2D and imperative SVG updates avoid React state updates every frame.
- The harmonic field deliberately uses Canvas2D rather than adding Three.js/R3F. It is a perspective-style ribbon field, not a 3D scene graph.
- Canvas DPR is capped at 1.5; line count drops on narrow viewports.
- Looping motion pauses offscreen and when the document is hidden. Time freezes, rather than jumping forward on resume.
- Reduced motion renders completed text, a static logo, a unison note, the finished chord, a centred metronome and a centred spotlight.
- Text is real text; decorative duplicates are hidden from assistive technology.
- SVG resources use per-instance IDs.
- Audio stops on release, closing the rail, blur and visibility changes; audio resources close on unmount.
- The UI does not use rapid strobing. Neon dips are restrained and can be disabled with `flicker={false}`.

Mobile Safari and physical-device performance still need checking in your target app; no unmeasured 60-fps or latency guarantees are made.

## What remains owned by the application

This is an animation kit. Your router, form validation, upload transport, consent processing, media access, analytics and backend stay in your app. The gallery currently accepts images; it does not include Mux playback, FLIP masonry reflow or shared-element navigation. The demo uses original vector stage illustrations, not real performance photography. Form progress is explicitly a preview slider, not a fake live upload.

The supplied prompt pack's optional sound effects for pillar cards, sample-library replacement, Web MIDI, Lottie/social exports, favicon set and advanced Next.js navigation interception are not included.

## Rebuild

```sh
npm ci
npm run build
```

This runs strict TypeScript checking and builds the self-contained HTML. `npm run preview` serves `dist/` at port 4173; open `/nextgen-noir-preview.html`. No runtime CDN or additional animation dependency is required.
